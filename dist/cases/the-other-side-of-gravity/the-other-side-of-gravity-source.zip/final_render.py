import bpy, math, os, sys
from mathutils import Vector
ROOT=os.path.dirname(os.path.abspath(__file__))
os.makedirs(ROOT+'/stills',exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
s=bpy.context.scene
s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=4;s.cycles.samples=16;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.15;s.cycles.adaptive_min_samples=4;s.cycles.use_denoising=False
s.render.resolution_x=1280;s.render.resolution_y=720;s.render.resolution_percentage=100
s.render.fps=24;s.frame_start=1;s.frame_end=576
s.world.color=(.14,.14,.14)
s.view_settings.view_transform='AgX'
s.render.image_settings.file_format='PNG'
def mat(name,col,metal,rough):
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 return m
copper=mat('Copper / microscratched foil',(.37,.13,.051),.86,.29)
nt=copper.node_tree;n=nt.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=185;n.inputs['Detail'].default_value=2
b=nt.nodes.new('ShaderNodeBump');b.inputs['Strength'].default_value=.15;b.inputs['Distance'].default_value=.018;nt.links.new(n.outputs['Fac'],b.inputs['Height']);nt.links.new(b.outputs['Normal'],nt.nodes.get('Principled BSDF').inputs['Normal'])
silver=mat('Brushed palladium',(.58,.67,.72),.96,.18)
floor=mat('Blue slate',(.026,.061,.067),.12,.44)
# Deterministic soft grounding pool, avoiding low-sample stochastic shadow shimmer.
fn=floor.node_tree; geo=fn.nodes.new('ShaderNodeNewGeometry'); le=fn.nodes.new('ShaderNodeVectorMath');le.operation='LENGTH';fn.links.new(geo.outputs['Position'],le.inputs[0]);r=fn.nodes.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=0;r.color_ramp.elements[0].color=(.006,.013,.016,1);r.color_ramp.elements[1].position=1;r.color_ramp.elements[1].color=(.026,.061,.067,1);div=fn.nodes.new('ShaderNodeMath');div.operation='DIVIDE';div.inputs[1].default_value=3.6;fn.links.new(le.outputs['Value'],div.inputs[0]);fn.links.new(div.outputs[0],r.inputs[0]);fn.links.new(r.outputs[0],fn.nodes.get('Principled BSDF').inputs['Base Color'])
def smooth(x):
 x=max(0,min(1,x));return x*x*(3-2*x)
def coords(i,u,v,t):
 theta=2*math.pi*i/24
 opening=smooth((t-8.0-i*.025-u*2.0)/6.5)
 dent=smooth((t-6)/1.7)*(1-.8*smooth((t-11)/6))
 # continuous lamella, flat initially then curls into an asymmetric upright bowl
 r=.12+2.75*u
 curl=opening*(1.12+.36*math.sin(theta))
 rr=.12+2.75*(math.sin(u*curl)/max(curl,.00001) if curl>.00001 else u)
 z=1.10-.65*dent*math.exp(-u*4)+2.75*(1-math.cos(u*curl))/max(curl,.00001)
 z+=1.10*smooth((t-15)/5)*(1-u)**2
 z+=.025*opening*math.sin(theta*2)*u
 # subtle radial vibration after contact, damped
 dt=max(0,t-6);z+=.035*math.sin(15*dt-u*12)*math.exp(-dt*.8)*smooth(dt*8)*(1-opening)*u
 angle=theta+v*(2*math.pi/24)*.475 +opening*.18*u
 rr+=.012*math.sin(v*math.pi)*u
 return (rr*math.cos(angle),rr*math.sin(angle),z)
blades=[]
NU=38;NV=6
for i in range(24):
 verts=[coords(i,j/NU,(k/NV*2-1),0) for j in range(NU+1) for k in range(NV+1)]
 faces=[]
 for j in range(NU):
  for k in range(NV):
   a=j*(NV+1)+k;faces.append((a,a+1,a+NV+2,a+NV+1))
 me=bpy.data.meshes.new('Radial foil');me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new('Lamella %02d'%i,me);bpy.context.collection.objects.link(o);o.data.materials.append(copper)
 for p in me.polygons:p.use_smooth=True
 mod=o.modifiers.new('Folded edge thickness','SOLIDIFY');mod.thickness=.007
 blades.append(o)
bpy.ops.mesh.primitive_uv_sphere_add(segments=64,ring_count=32,radius=.22,location=(0,0,3.6));bead=bpy.context.object;bead.name='The burden returned';bead.data.materials.append(silver)
for p in bead.data.polygons:p.use_smooth=True
# a small central seat joins the lamellae
bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=24,radius=1);hub=bpy.context.object;hub.scale=(.22,.22,.065);hub.data.materials.append(copper)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.17));bpy.context.object.data.materials.append(floor)
# A visible telescoping spine makes the transformation an honest kinetic sculpture.
bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.047,depth=1.3,location=(0,0,.48));spine=bpy.context.object;spine.data.materials.append(silver)
bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.24,depth=.055,location=(0,0,-.14));bpy.context.object.data.materials.append(copper)
def light(name,loc,power,col,size,sy=None):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.color=col;d.use_shadow=False;d.shape='RECTANGLE';d.size=size;d.size_y=sy or size;o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,1.2))-o.location).to_track_quat('-Z','Y').to_euler()
light('Broad silk',(-3,-4,7),1100,(1,.86,.70),5,3)
light('Cold vertical edge',(3,2,5),1500,(.62,.83,1),3,5)
light('Warm rear contour',(-3,4,3.4),1000,(1,.52,.23),2,4)
light('Front fill',(1,-5,2.5),260,(.72,.86,1),4,2)
d=bpy.data.cameras.new('Camera');cam=bpy.data.objects.new('Camera',d);bpy.context.collection.objects.link(cam);s.camera=cam;d.lens=48

def update(scene):
 t=(scene.frame_current-1)/24
 for i,o in enumerate(blades):
  for j in range(NU+1):
   for k in range(NV+1):o.data.vertices[j*(NV+1)+k].co=coords(i,j/NU,k/NV*2-1,t)
  o.data.update()
 fall=smooth((t-3)/3)**1.8;dent=smooth((t-6)/1.7)*(1-.8*smooth((t-11)/6))
 z=3.6-.025*smooth(t/3)-2.19*fall-.65*dent+1.10*smooth((t-15)/5)
 bead.location=(0,0,z);hub.location=(0,0,1.10-.65*dent+1.10*smooth((t-15)/5))
 spine.scale.z=(hub.location.z+.17)/1.3;spine.location.z=(hub.location.z-.17)/2
 # slow orbit with a lower angle at the lift, followed by a gentle release
 az=-math.pi*.5+.12+.29*smooth(t/24);dist=12.0-.5*smooth(t/6)+.8*smooth((t-18)/6)
 cam.location=(dist*math.cos(az),dist*math.sin(az),7.8+1.6*smooth((t-9)/9))
 target=Vector((0,0,1.30+.35*smooth((t-12)/7)));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
bpy.app.handlers.frame_change_pre.append(update)
s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/gravity.blend')
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if 'preview' in args:
 s.render.resolution_percentage=50
 for name,start,end in [('contact',121,192),('lift',361,480)]:
  s.frame_start=start;s.frame_end=end;s.render.filepath=ROOT+'/preview_'+name+'/';os.makedirs(s.render.filepath,exist_ok=True);bpy.ops.render.render(animation=True)
elif 'repro' in args:
 import hashlib,json
 hashes=[]
 for name in ('repro_a','repro_b'):
  s.frame_set(500);s.frame_set(52);s.frame_set(337);s.render.filepath=ROOT+'/stills/'+name+'.png';bpy.ops.render.render(write_still=True)
  hashes.append(hashlib.sha256(open(s.render.filepath,'rb').read()).hexdigest())
 open(ROOT+'/reproducibility.json','w').write(json.dumps({'frame':337,'sha256':hashes,'byte_identical':hashes[0]==hashes[1]},indent=2))
elif 'validate' in args:
 import json, hashlib
 from bpy_extras.object_utils import world_to_camera_view
 gaps=[];heights=[];occluded=[];bounds=[]
 for fr in range(1,577):
  s.frame_set(fr);bpy.context.view_layer.update()
  if fr>=145:gaps.append(bead.location.z-.22-(hub.location.z+.065))
  heights.append(hub.location.z)
  hit,loc,norm,idx,obj,mat=s.ray_cast(bpy.context.evaluated_depsgraph_get(),cam.location,(bead.location-cam.location).normalized())
  if not hit or obj.name!=bead.name:occluded.append({'frame':fr,'first_object':obj.name if hit else None})
  uv=world_to_camera_view(s,cam,bead.location);bounds.append([uv.x,uv.y])
 def signature(fr):
  s.frame_set(fr);return hashlib.sha256(repr(([tuple(v.co) for o in blades for v in o.data.vertices],tuple(bead.location),tuple(cam.location))).encode()).hexdigest()
 sig1=signature(337);signature(500);signature(52);sig2=signature(337)
 report={'frames_checked':576,'contact_frame':145,'contact_gap_min':min(gaps),'contact_gap_max':max(gaps),'lowest_center_time':heights.index(min(heights))/24,'lowest_center_z':min(heights),'highest_center_time':heights.index(max(heights))/24,'highest_center_z':max(heights),'bead_center_occluded_frames':occluded,'bead_center_ndc_min':[min(x[i] for x in bounds) for i in range(2)],'bead_center_ndc_max':[max(x[i] for x in bounds) for i in range(2)],'out_of_order_geometry_hash_equal':sig1==sig2,'hash':sig1,'caveat':'Ray checks test center visibility, not every silhouette point. Stylized prescribed deformation, not physics simulation.'}
 open(ROOT+'/validation.json','w').write(json.dumps(report,indent=2));print('VALIDATION',json.dumps(report))
elif 'stills' in args:
 for t in (2,7.5,19):
  s.frame_set(int(t*24)+1);s.render.filepath=ROOT+'/stills/final_%04d.png'%int(t*100);bpy.ops.render.render(write_still=True)
elif 'short' in args:
 s.frame_start=325;s.frame_end=354;s.render.filepath=ROOT+'/short/';os.makedirs(s.render.filepath,exist_ok=True);bpy.ops.render.render(animation=True)
else:
 s.render.filepath=ROOT+'/frames/';os.makedirs(s.render.filepath,exist_ok=True);bpy.ops.render.render(animation=True)
