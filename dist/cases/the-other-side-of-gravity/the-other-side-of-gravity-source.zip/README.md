# 重力的另一面 / The Other Side of Gravity

24 秒原创 coding motion。银珠压低铜盘，弯曲沿薄铜片展开，中央托座最后把银珠抬回光里。每个画面均由 Blender 程序几何渲染，配乐与金属声由 Python 独立合成，没有外部图片、模型、素材音轨、TTS 或生成视频调用。

## 文件

- `final_render.py`：最终 24 铜瓣场景、材质、镜头与确定性动画。不是早期 44 瓣实验稿。
- `gravity.blend`：可编辑的静态场景快照。它不保存 Python 帧回调，不能独立播放完整动画；完整动画由上面的源码重建。
- `build.py`：从场景与音频源码重建完整 MP4。
- `audio/compose.py`、`audio/master_audio.py`：原创音符、音效事件与双遍响度处理。
- `audio/music.flac`、`foley.flac`、`master.flac`：无损音乐、音效与最终混音。FLAC 是同一作品的分轨，不是独立案例。
- `visual_events.json`、`validation.json`、`reproducibility.json`、`verification.json`：时间点与实际验证记录。
- `poster.png`：影片真实渲染帧，不是另行生成的封面。
- `MANIFEST.sha256`：源包内文件的 SHA-256。

## 复现

制作环境：Blender 4.3.2，FFmpeg 7.1.5，Python 3，NumPy 2.3.5，SciPy 1.17。源码不下载网络依赖，不调用付费服务。

在解压目录运行：

```sh
python build.py
```

会生成 576 张 1280×720、24 fps 的真实渲染帧，并制作 48 kHz 双声道音轨和 H.264/AAC MP4。需要等待完整渲染。已有最终帧时可用 `python build.py --reuse-frames` 重建音画合成。

单独检查：

```sh
blender -b -t 8 -P final_render.py -- stills
blender -b -t 8 -P final_render.py -- validate
blender -b -t 8 -P final_render.py -- repro
```

## 叙事时间线

- 0–3 秒：银珠悬停，镜头缓慢靠近。
- 3–6 秒：银珠下降，6.000 秒接触托座。
- 6–7.708 秒：中央受压到最低点。
- 8–15 秒：弯曲从内部向外传播，铜瓣依次反卷。
- 15–20 秒：中央托座抬升，银珠始终留在其上。
- 20–24 秒：新的形态保留，镜头轻轻退开，声音收束。

## 诚实边界

这是规定几何轨迹的诗性机械雕塑，不是铜片物理仿真，也不表示真实机构可以如此制造。EEVEE 使用 4 采样；地面采用确定性的暗色渐变表现承托关系，灯光未启用随机投射阴影。薄缝用于避免相邻铜片共面重叠造成闪烁。

`verification.json` 区分实际通过的技术/画面检查与未完成的完整原速浏览器观看、主观听审。抽帧、解码、响度或可见性数值不等于艺术验收。素材作为第五件独立原创候选，不把封面、分轨或格式衍生品重复计数。

作品与源码为本次任务制作；未设置对公众的复用许可，也不作版权或独创性的法律保证。
