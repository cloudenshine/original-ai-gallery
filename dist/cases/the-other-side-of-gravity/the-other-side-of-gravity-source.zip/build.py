"""Build the original 24-second film from code. Dependencies: Blender 4.3.2,
FFmpeg 7.x, Python 3 with NumPy and SciPy. No network or paid service used.
Use --reuse-frames only when all 576 final-render PNG frames already exist.
"""
from pathlib import Path
import subprocess, sys, argparse
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--reuse-frames',action='store_true');a=p.parse_args()
def run(cmd):subprocess.run(cmd,cwd=R,check=True)
if not a.reuse_frames:run(['blender','-b','-t','8','-P',str(R/'final_render.py')])
for i in range(1,577):
 if not (R/'frames'/f'{i:04d}.png').exists():raise SystemExit(f'Missing final frame {i}; rerun without --reuse-frames')
run([sys.executable,str(R/'audio/compose.py')]);run([sys.executable,str(R/'audio/master_audio.py')])
run(['ffmpeg','-y','-framerate','24','-start_number','1','-i',str(R/'frames/%04d.png'),'-i',str(R/'audio/master.wav'),'-map','0:v:0','-map','1:a:0','-frames:v','576','-t','24','-c:v','libx264','-preset','slow','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','256k','-ar','48000','-movflags','+faststart','-metadata','title=重力的另一面 / The Other Side of Gravity',str(R/'the-other-side-of-gravity.mp4')])
print('Built the-other-side-of-gravity.mp4')
