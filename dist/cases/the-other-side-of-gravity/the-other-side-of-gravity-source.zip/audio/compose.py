"""Original physical-model score and metal foley for The Other Side of Gravity.
No downloaded samples. Deterministic seed, fixed event times, stereo 48 kHz.
"""
from pathlib import Path
import json
import numpy as np
from scipy import signal
from scipy.io import wavfile
SR=48000; DUR=24.; N=int(SR*DUR)
ROOT=Path(__file__).resolve().parent
rng=np.random.default_rng(11112026)
music=np.zeros((N,2)); foley=np.zeros((N,2))

def fade(x,a=.015,b=.2):
 x=x.copy(); na=min(len(x),int(a*SR)); nb=min(len(x),int(b*SR))
 if na: x[:na]*=np.sin(np.linspace(0,np.pi/2,na))**2
 if nb:x[-nb:]*=np.cos(np.linspace(0,np.pi/2,nb))**2
 return x

def add(buf,x,at,gain=1,pan=0):
 start=int(round(at*SR)); l=min(len(x),N-start)
 if l<=0:return
 p=(pan+1)*np.pi/4
 buf[start:start+l,0]+=x[:l]*gain*np.cos(p)
 buf[start:start+l,1]+=x[:l]*gain*np.sin(p)

def pluck(freq,seconds=3.8,soft=.65):
 # Karplus–Strong loop: a short seeded noise excitation enters a low-pass delay.
 length=max(2,int(SR/freq-.5)); n=int(seconds*SR)
 excitation=rng.normal(0,1,length)
 excitation=signal.lfilter([.2,.6,.2],[1],excitation)
 excitation-=excitation.mean(); excitation/=max(np.max(abs(excitation)),1e-9)
 impulse=np.zeros(n);impulse[:length]=excitation
 denom=np.zeros(length+2);denom[0]=1;denom[length]=-.496;denom[length+1]=-.496
 x=signal.lfilter([1],denom,impulse)
 x=signal.sosfilt(signal.butter(2,2800 if soft else 4700,fs=SR,output='sos'),x)
 return fade(x,.005,.35)

def modal(freq,seconds=4,bright=.55):
 t=np.arange(int(seconds*SR))/SR;x=np.zeros(len(t))
 for i,ratio in enumerate([1,1.48,2.09,2.82,3.93,5.12]):
  decay=seconds/(1+.4*i)
  x+=bright**i*np.sin(2*np.pi*freq*ratio*t+.17*i)*np.exp(-t/max(.12,decay*.43))
 return fade(x,.002,.35)

def rub(seconds,center=2100):
 n=int(seconds*SR);t=np.arange(n)/SR
 x=signal.sosfilt(signal.butter(3,[650,center],btype='bandpass',fs=SR,output='sos'),rng.normal(size=n))
 env=(.35+.65*np.sin(np.pi*np.minimum(t/seconds,1))**2)*(1+.14*np.sin(2*np.pi*17*t))
 x=x*env; x/=max(np.max(abs(x)),1e-9)
 return fade(x,.15,.35)

def bowed(freq,seconds):
 t=np.arange(int(seconds*SR))/SR;x=np.zeros(len(t));drift=.0018*np.sin(2*np.pi*.22*t)
 for k,amp in enumerate([1,.24,.12,.05],start=1):x+=amp*np.sin(2*np.pi*k*freq*(t+drift))
 x*=np.sin(np.pi*t/seconds)**1.6
 return fade(x,.6,.7)*.25

# Intentionally incomplete opening fifth. The first low note waits for contact.
add(music,bowed(220,5.5),0,.12,-.2)
add(music,pluck(329.627,4),.65,.095,.35)
add(music,pluck(293.665,3.5),2.7,.07,-.35)
add(music,bowed(246.942,3.4),3.1,.11,.25)
# Development: a rising four-note cell becomes wider rather than faster.
score=[(6.05,146.832,.17,-.1),(7.15,220,.1,-.4),(8.55,293.665,.13,.15),
 (9.75,329.627,.11,-.15),(11.15,440,.12,.35),(12.55,391.995,.11,-.3),
 (14.05,293.665,.13,-.35),(14.8,440,.13,.12),(15.65,493.883,.12,.3),
 (17.1,587.330,.13,-.1),(18.55,440,.105,.2),(20.1,329.627,.095,-.25),
 (21.45,293.665,.10,.15)]
for at,f,g,p in score:add(music,pluck(f, min(4.0,DUR-at)),at,g,p)
add(music,bowed(293.665,6),8.25,.11,-.3)
add(music,bowed(391.995,6),12.2,.095,.3)
add(music,bowed(220,5.3),18.5,.075,-.05)
# Main metal impact: single precise transient with a long, thin plate tail.
add(foley,modal(164.814,5.4,.61),6,.20,-.02)
add(foley,modal(698.456,1.65,.48),6,.035,.08)
add(foley,fade(rng.normal(0,1,int(.035*SR)),.001,.025),6,.025)
# Very subtle falling air, then a separate material contraction.
add(foley,rub(2.9,4200),3.05,.016,.04)
# Six successive copper curls, including lateral motion, all use the event map.
for i,at in enumerate([8.5,9.4,10.3,11.2,12.1,13.]):
 add(foley,rub(1.35,2400+130*i),at,.022,-.55+i*.22)
 add(foley,modal(330+33*i,1.2,.4),at+.1,.012,-.55+i*.22)
add(foley,modal(261.626,2.8,.48),20,.045,.05)
add(foley,rub(.85,1800),20.12,.014,-.1)
# Room: deterministic early reflections, never reused as a separate score.
def room(buf):
 out=buf.copy()
 for delay,g,cross in [(0.041,.15,True),(.073,.11,False),(.127,.08,True),(.211,.05,False),(.337,.035,True)]:
  n=int(delay*SR); v=buf[:-n,::-1] if cross else buf[:-n]
  out[n:]+=g*v
 return out
music=room(music);foley=room(foley)
# Remove subsonic energy and apply a content-shaped fade, not abrupt truncation.
for buf in [music,foley]:
 buf[:]=signal.sosfilt(signal.butter(2,42,btype='highpass',fs=SR,output='sos'),buf,axis=0)
 ramp=np.ones(N);ramp[:int(.08*SR)]=np.linspace(0,1,int(.08*SR))
 ramp[int(23.2*SR):]=np.cos(np.linspace(0,np.pi/2,N-int(23.2*SR)))**2
 buf*=ramp[:,None]
raw=music+foley
peak=max(float(abs(raw).max()),1e-9);scale=.84/peak
music*=scale;foley*=scale;raw*=scale
for name,buf in [('music',music),('foley',foley),('mix-pre-master',raw)]:
 wavfile.write(ROOT/(name+'.wav'),SR,np.clip(buf,-1,1).astype(np.float32))
report={'duration_seconds':DUR,'sample_rate':SR,'channels':2,'original_composition':True,'external_samples':False,'synthesis':'Karplus–Strong plucked string, bowed harmonic voice, inharmonic metal modes and filtered-noise copper friction','seed':11112026,'music_notes':[{'time':a,'frequency_hz':f,'gain':g,'pan':p} for a,f,g,p in score],'events':[{'time':6.,'name':'sphere_contact'},{'time':8.5,'name':'curl_begin'},{'time':15.,'name':'lift_begin'},{'time':20.,'name':'lift_complete'},{'time':21.,'name':'settle'}],'pre_master_peak':float(abs(raw).max()),'subjective_listening':'Not yet verified'}
(ROOT/'audio-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(ROOT),'seconds':DUR,'peak':report['pre_master_peak']}))
