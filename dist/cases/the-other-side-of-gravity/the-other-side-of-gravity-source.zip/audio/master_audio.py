"""Reproducible two-pass mastering and lossless stem packaging. Requires ffmpeg."""
from pathlib import Path
import subprocess,json,re,hashlib
import numpy as np
from scipy.io import wavfile
R=Path(__file__).resolve().parent

def run(args):
 return subprocess.run(args,check=True,capture_output=True,text=True)
def loudness(path):
 p=run(['ffmpeg','-hide_banner','-i',str(path),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'])
 return json.loads(re.findall(r'\{[^{}]*\}',p.stderr,re.S)[-1])
x=loudness(R/'mix-pre-master.wav')
f=f"loudnorm=I=-16:TP=-1.5:LRA=9:measured_I={x['input_i']}:measured_TP={x['input_tp']}:measured_LRA={x['input_lra']}:measured_thresh={x['input_thresh']}:offset={x['target_offset']}:linear=true:print_format=json"
run(['ffmpeg','-y','-hide_banner','-i',str(R/'mix-pre-master.wav'),'-af',f,'-ar','48000','-c:a','pcm_s24le',str(R/'master.wav')])
r=json.loads((R/'audio-report.json').read_text());r['signal_checks']={}
for name in ['music','foley','master']:
 path=R/(name+'.wav')
 run(['ffmpeg','-y','-hide_banner','-i',str(path),'-c:a','flac','-compression_level','8',str(R/(name+'.flac'))])
 sr,y=wavfile.read(path)
 if np.issubdtype(y.dtype,np.integer):y=y.astype(float)/max(abs(np.iinfo(y.dtype).min),np.iinfo(y.dtype).max)
 else:y=y.astype(float)
 r['signal_checks'][name]={'sample_rate':sr,'channels':y.shape[1],'samples':len(y),'duration_seconds':len(y)/sr,'finite':bool(np.isfinite(y).all()),'sample_peak_dbfs':float(20*np.log10(abs(y).max())),'clip_samples':int(np.count_nonzero(abs(y)>=1)),'mono_rms_dbfs':float(20*np.log10(np.sqrt(np.mean(y.mean(axis=1)**2)))),'flac_sha256':hashlib.sha256((R/(name+'.flac')).read_bytes()).hexdigest()}
y=loudness(R/'master.wav');r['measured_final_master']={'integrated_lufs':float(y['input_i']),'true_peak_dbtp':float(y['input_tp']),'lra_lu':float(y['input_lra']),'sample_rate':48000,'duration_seconds':24.0}
r['subjective_listening']='Attempted audio input through available tool on 2026-11-11; tool explicitly reported audio input unsupported. Listening not verified.'
(R/'audio-report.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(r['measured_final_master']))
