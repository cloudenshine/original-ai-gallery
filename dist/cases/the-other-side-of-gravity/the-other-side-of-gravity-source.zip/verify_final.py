"""Technical verification, deliberately separate from subjective audiovisual review."""
from pathlib import Path
import subprocess, json, hashlib, re
import numpy as np
R=Path(__file__).resolve().parent
P=R/'the-other-side-of-gravity.mp4'
def run(args):return subprocess.run(args,check=True,capture_output=True)
probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(P)]).stdout)
video=next(x for x in probe['streams'] if x['codec_type']=='video');audio=next(x for x in probe['streams'] if x['codec_type']=='audio')
dec=run(['ffmpeg','-v','error','-i',str(P),'-f','null','-'])
x=run(['ffmpeg','-v','error','-i',str(P),'-map','0:v:0','-vf','scale=160:90','-pix_fmt','rgb24','-f','rawvideo','-']).stdout
frames=np.frombuffer(x,np.uint8).reshape(-1,90,160,3);d=np.abs(np.diff(frames.astype(np.float32),axis=0)).mean(axis=(1,2,3))
a=run(['ffmpeg','-v','error','-i',str(P),'-map','0:a:0','-ar','48000','-ac','2','-f','f32le','-']).stdout
y=np.frombuffer(a,'<f4').reshape(-1,2)
l=run(['ffmpeg','-hide_banner','-i',str(P),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']).stderr.decode()
loud=json.loads(re.findall(r'\{[^{}]*\}',l,re.S)[-1])
report={
 'title':'重力的另一面 / The Other Side of Gravity','verification_date':'2026-11-11',
 'video':{k:video.get(k) for k in ['codec_name','width','height','pix_fmt','r_frame_rate','nb_frames','duration']},
 'audio':{k:audio.get(k) for k in ['codec_name','sample_rate','channels','channel_layout','duration']},
 'complete_decode':{'exit_code':dec.returncode,'stderr':dec.stderr.decode(),'decoded_video_frames':len(frames),'decoded_audio_samples':len(y),'decoded_audio_seconds':len(y)/48000},
 'motion_signal':{'preview_resolution':[160,90],'unique_decoded_frame_hashes':len({hashlib.sha256(f.tobytes()).hexdigest() for f in frames}),'mean_rgb_change_min':float(d.min()),'mean_rgb_change_max':float(d.max()),'mean_rgb_change_p95':float(np.quantile(d,.95)),'dark_frame_mean_min':float(frames.mean(axis=(1,2,3)).min()),'note':'Numerical change confirms no repeated frozen frames; it does not establish cinematic rhythm.'},
 'final_aac_signal':{'finite':bool(np.isfinite(y).all()),'clipped_samples':int(np.count_nonzero(np.abs(y)>=1)),'sample_peak_dbfs':float(20*np.log10(abs(y).max())),'integrated_lufs':float(loud['input_i']),'true_peak_dbtp':float(loud['input_tp']),'lra_lu':float(loud['input_lra'])},
 'source_sha256':hashlib.sha256((R/'final_render.py').read_bytes()).hexdigest(),
 'film_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),
 'film_size_bytes':P.stat().st_size,
 'geometry':json.loads((R/'validation.json').read_text()),
 'pixel_reproducibility':json.loads((R/'reproducibility.json').read_text()),
 'visual_review':{'sampled_frames_and_contact_sheets':True,'revisions':'Replaced 44 uniform pleats with 24 asymmetric lamellae; removed coplanar overlap; showed bead and center lift. Full-film sample review recorded separately.','full_speed_continuous_viewing':False},
 'subjective_listening':{'verified':False,'reason':'Available audio-input tool reported audio input unsupported.'},
 'actual_browser_playback':{'verified':False,'reason':'Cloud browser could not reach execution-host localhost; two explicit local-server attempts returned ERR_CONNECTION_REFUSED.'},
 'limitations':['Prescribed stylized geometry, not physical simulation.','Static .blend snapshot; final_render.py regenerates the animation.','Technical verification and sampled imagery are not final subjective audiovisual acceptance.'],
}
assert len(frames)==576 and int(video['width'])==1280 and int(video['height'])==720
assert video['r_frame_rate']=='24/1' and abs(float(video['duration'])-24)<.01
assert audio['sample_rate']=='48000' and audio['channels']==2
assert np.isfinite(y).all() and not np.count_nonzero(np.abs(y)>=1)
(R/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['video','audio','complete_decode','motion_signal','final_aac_signal']},ensure_ascii=False,indent=2))
