/** Original procedural paper-cut film. No fonts, stock assets or paid services. */
const {createCanvas}=require('@napi-rs/canvas');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const ROOT=__dirname,OUT=path.join(ROOT,'output');
const args=Object.fromEntries(process.argv.slice(2).map(x=>x.replace(/^--/,'').split('=')));
const mode=args.mode||'preview';
const W=1280,H=720,FPS=24,DURATION=20;
fs.mkdirSync(OUT,{recursive:true});
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d');
let seed=84217;function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
function ease(t,a,b){const u=clamp((t-a)/(b-a));return u*u*u*(10+u*(-15+6*u));}
const mix=(a,b,u)=>a+(b-a)*u;
function noiseTexture(){const c=createCanvas(512,512),q=c.getContext('2d'),im=q.createImageData(512,512);for(let i=0;i<512*512;i++){const white=rand()>.48,v=white?255:20;im.data[i*4]=v;im.data[i*4+1]=v;im.data[i*4+2]=v;im.data[i*4+3]=Math.floor(3+rand()*15);}q.putImageData(im,0,0);q.strokeStyle='rgba(94,67,42,.10)';q.lineWidth=.45;for(let k=0;k<1150;k++){const x=rand()*512,y=rand()*512;q.beginPath();q.moveTo(x,y);q.lineTo(x+1+rand()*5,y+rand()*1.8-.9);q.stroke();}return c;}
const paper=noiseTexture(),grain=ctx.createPattern(paper,'repeat');
function texture(alpha=1){ctx.save();ctx.globalAlpha=alpha;ctx.fillStyle=grain;ctx.fillRect(-2000,-2000,4000,4000);ctx.restore();}
function silhouette(draw,fill,shadow=0){ctx.save();if(shadow){ctx.shadowColor='rgba(32,29,24,.22)';ctx.shadowBlur=shadow;ctx.shadowOffsetY=shadow*.55;}ctx.beginPath();draw();ctx.fillStyle=fill;ctx.fill();ctx.restore();ctx.save();ctx.beginPath();draw();ctx.clip();texture(.8);ctx.restore();}
function groundY(x){return 420-.022*(x-1050)+1.1*Math.sin((x-1050)/54)*ease(x,1050,1090);}
function landPath(){ctx.moveTo(1050,420);for(let x=1055;x<=1320;x+=5)ctx.lineTo(x,groundY(x));ctx.lineTo(1320,760);ctx.lineTo(988,760);ctx.bezierCurveTo(1005,640,990,505,1024,452);ctx.bezierCurveTo(1034,437,1042,424,1050,420);ctx.closePath();}
const pebbles=Array.from({length:18},()=>({x:1080+rand()*190,y:460+rand()*215,r:2+rand()*5,angle:rand()*6.28}));
function background(t){let g=ctx.createLinearGradient(0,0,W,H);g.addColorStop(0,'#f3e6c8');g.addColorStop(.55,'#ead7b4');g.addColorStop(1,'#e0c29a');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);texture(.65);
 // Gentle paper illumination is stationary, never a floating effect.
 g=ctx.createRadialGradient(405,170,20,405,170,700);g.addColorStop(0,'rgba(255,251,228,.30)');g.addColorStop(1,'rgba(255,251,228,0)');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
}
function water(t,s){
 const localContact=t<11.7?mix(-390,-350,ease(t,11.5,11.7)):-350+20*ease(t,11.7,13)+30*ease(t,13,16);
 const yy=leafLocal(localContact,s);
 const under=2.8+6*Math.sin(Math.PI*clamp((localContact+500)/500))**.7;
 const contactX=s.rootX+Math.cos(s.theta)*localContact-Math.sin(s.theta)*(yy+under);
 const contactY=s.rootY+Math.sin(s.theta)*localContact+Math.cos(s.theta)*(yy+under);
 const center=t<11.5?mix(420,contactX,ease(t,9.8,11.5)):contactX;
 const base=(x)=>{const moving=(tt)=>450+1.4*Math.sin(x*.010-tt*.9)+.65*Math.sin(x*.025+tt*.7);if(t<18)return moving(t);const underLeaf=ease(x,s.rootX-515,s.rootX-500)*(1-ease(x,s.rootX,s.rootX+15));return mix(moving(t),moving(18),underLeaf);};
 const targetHeight=Math.max(0,base(center)-contactY),meet=ease(t,11.5,11.7);
 const incoming=Math.min(3,targetHeight*.7)*ease(t,10.9,11.5);
 const height=mix(incoming,targetHeight,meet);
 // The visible crest reaches the underside at 11.7s and keeps its contact as it travels.
 function top(x){const raw=base(x)-height*Math.exp(-(((x-center)/142)**2));const under=leafUnderside(x,s);return Number.isFinite(under)?Math.max(raw,under):raw;}
 let g=ctx.createLinearGradient(0,440,0,720);g.addColorStop(0,'#3d6b68');g.addColorStop(.45,'#254e54');g.addColorStop(1,'#193f49');
 silhouette(()=>{ctx.moveTo(-10,top(-10));for(let x=-5;x<=1300;x+=5)ctx.lineTo(x,top(x));ctx.lineTo(1300,730);ctx.lineTo(-10,730);ctx.closePath();},g,0);
 ctx.save();ctx.beginPath();ctx.moveTo(-10,top(-10));for(let x=0;x<=1300;x+=5)ctx.lineTo(x,top(x));ctx.lineTo(1300,730);ctx.lineTo(-10,730);ctx.closePath();ctx.clip();
 // A matte crest fold makes the approaching support visible; it is not a diagram label.
 const crestAlpha=.32*ease(t,10.9,11.5)*(1-ease(t,16,18));
 if(crestAlpha>0){const cg=ctx.createLinearGradient(center-170,0,center+180,0);cg.addColorStop(0,'rgba(190,215,189,0)');cg.addColorStop(.40,`rgba(190,215,189,${crestAlpha})`);cg.addColorStop(.64,`rgba(190,215,189,${crestAlpha*.85})`);cg.addColorStop(1,'rgba(190,215,189,0)');ctx.beginPath();ctx.moveTo(center-170,top(center-170)+1);for(let x=center-165;x<=center+180;x+=5)ctx.lineTo(x,top(x)+1);for(let x=center+180;x>=center-170;x-=5)ctx.lineTo(x,top(x)+11);ctx.closePath();ctx.fillStyle=cg;ctx.fill();}
 // Broad cut-paper currents, each attached to the same water field.
 for(let k=0;k<4;k++){const yy=500+k*70;ctx.beginPath();ctx.moveTo(-100,yy);for(let x=-100;x<=1400;x+=10)ctx.lineTo(x,yy+12*Math.sin(x*.005+k*1.7-t*.20));ctx.lineTo(1400,yy+46);for(let x=1400;x>=-100;x-=10)ctx.lineTo(x,yy+25+12*Math.sin(x*.005+k*1.7-t*.20));ctx.closePath();ctx.fillStyle=k%2?'rgba(97,144,137,.10)':'rgba(8,34,44,.11)';ctx.fill();}
 ctx.restore();ctx.beginPath();for(let x=-10;x<=1050;x+=4){if(x===-10)ctx.moveTo(x,top(x));else ctx.lineTo(x,top(x));}ctx.strokeStyle='rgba(220,226,190,.52)';ctx.lineWidth=1.5;ctx.stroke();
 return {center,height,contactX,contactY,crestY:top(center)};
}
function land(t){let g=ctx.createLinearGradient(920,410,1170,720);g.addColorStop(0,'#b4784e');g.addColorStop(.45,'#925539');g.addColorStop(1,'#70402f');silhouette(landPath,g,6);
 ctx.save();ctx.beginPath();landPath();ctx.clip();ctx.strokeStyle='rgba(69,38,28,.13)';ctx.lineWidth=1.1;
 for(let k=0;k<6;k++){ctx.beginPath();for(let x=1010;x<=1320;x+=8){const y=493+k*43+9*Math.sin(x*.009+k*.8);if(x===1010)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.stroke();}
 // Sparse pressed soil flecks are surface structure, not floating decorations.
 for(const p of pebbles){ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.angle);ctx.fillStyle='rgba(51,39,31,.18)';ctx.beginPath();ctx.ellipse(0,0,p.r,p.r*.42,0,0,Math.PI*2);ctx.fill();ctx.restore();}ctx.restore();
 // The top contact line remains unobscured all the way across the joint.
 ctx.beginPath();ctx.moveTo(1050,420);for(let x=1055;x<=1300;x+=5)ctx.lineTo(x,groundY(x));ctx.strokeStyle='#c89462';ctx.lineWidth=2.2;ctx.stroke();
}
function state(t){
 const route=[[0,530,4],[4,550,10],[7,800,100],[10,1050,8],[11.5,1054,0]];
 let rootX=1054;
 for(let j=0;j<route.length-1;j++){const[a,ya,ma]=route[j],[b,yb,mb]=route[j+1];if(t<=b){const u=clamp((t-a)/(b-a)),h=b-a;rootX=(2*u**3-3*u*u+1)*ya+(u**3-2*u*u+u)*h*ma+(-2*u**3+3*u*u)*yb+(u**3-u*u)*h*mb;break;}}
 const rootY=rootX<=1050?420:groundY(rootX);
 const theta=(t<1.4?-.035*Math.sin(Math.PI*t/1.4):0)+.08*ease(t,11.7,13)-.008*ease(t,16,18);const depth=mix(30,5,ease(t,11.7,13))+2.5*ease(t,16,18);
 let rel=mix(-335,-435,ease(t,0,1.4));
 if(t>=12.5){const knots=[[12.5,-435,0],[14,0,132],[14.6,57,64],[16,105,0]];rel=105;for(let j=0;j<knots.length-1;j++){const[a,ya,ma]=knots[j],[b,yb,mb]=knots[j+1];if(t<=b){const u=clamp((t-a)/(b-a)),h=b-a;rel=(2*u**3-3*u*u+1)*ya+(u**3-2*u*u+u)*h*ma+(-2*u**3+3*u*u)*yb+(u**3-u*u)*h*mb;break;}}}
 return {t,rootX,rootY,theta,depth,rel};}
function leafLocal(x,s){const u=clamp((x+500)/500);const give=4.5*ease(s.t,.9,1.4)*(1-.55*ease(s.t,1.4,2.3))*(1-ease(s.t,12.5,13.2))*Math.exp(-(((x+450)/35)**2));return give+ -65*(1-u)**10+s.depth*Math.sin(Math.PI*u)**2+.7*Math.sin(x*.031)*Math.sin(Math.PI*u);}
function leafSurface(wx,s){let x=(wx-s.rootX)/Math.cos(s.theta);for(let j=0;j<4;j++)x=(wx-s.rootX+Math.sin(s.theta)*leafLocal(x,s))/Math.cos(s.theta);return s.rootY+Math.sin(s.theta)*x+Math.cos(s.theta)*leafLocal(x,s);}
function leafUnderside(wx,s){
 const thick=x=>2.8+6*Math.sin(Math.PI*clamp((x+500)/500))**.7;
 const left=s.rootX+Math.cos(s.theta)*(-500)-Math.sin(s.theta)*(leafLocal(-500,s)+thick(-500));
 const right=s.rootX-Math.sin(s.theta)*thick(0);
 if(wx<left || wx>right)return NaN;
 let x=(wx-s.rootX)/Math.cos(s.theta);
 for(let k=0;k<5;k++)x=(wx-s.rootX+Math.sin(s.theta)*(leafLocal(x,s)+thick(x)))/Math.cos(s.theta);
 return s.rootY+Math.sin(s.theta)*x+Math.cos(s.theta)*(leafLocal(x,s)+thick(x));
}
function leaf(t,s){ctx.save();ctx.translate(s.rootX,s.rootY);ctx.rotate(s.theta);
 const span=x=>25*Math.sin(Math.PI*clamp((x+500)/500))**.8;
 const shape=()=>{ctx.moveTo(-500,leafLocal(-500,s));for(let x=-495;x<=0;x+=5)ctx.lineTo(x,leafLocal(x,s)-span(x));ctx.lineTo(1,2);for(let x=0;x>=-500;x-=5){const u=clamp((x+500)/500);ctx.lineTo(x,leafLocal(x,s)+2.8+6*Math.sin(Math.PI*u)**.7);}ctx.closePath();};
 let g=ctx.createLinearGradient(-500,-15,-80,40);g.addColorStop(0,'#ac4c28');g.addColorStop(.4,'#d77b3f');g.addColorStop(1,'#e39a54');silhouette(shape,g,3);
 // The front cross-section is the contact surface; the shallow rear leaf face gives identity.
 ctx.beginPath();ctx.moveTo(-500,leafLocal(-500,s));for(let x=-495;x<=0;x+=5)ctx.lineTo(x,leafLocal(x,s));ctx.strokeStyle='#efb975';ctx.lineWidth=1.35;ctx.stroke();
 ctx.beginPath();for(let x=-480;x<=-15;x+=5){const y=leafLocal(x,s)-span(x)*.48;if(x===-480)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.strokeStyle='rgba(124,55,28,.38)';ctx.lineWidth=.8;ctx.stroke();
 ctx.strokeStyle='rgba(125,56,27,.31)';ctx.lineWidth=.6;
 for(let x=-446,k=0;x<-30;x+=39,k++){
  const y=leafLocal(x,s)-span(x)*.48;ctx.beginPath();ctx.moveTo(x,y);ctx.quadraticCurveTo(x+8,y-span(x)*.18,x+16,leafLocal(x+16,s)-span(x+16)*.88);ctx.stroke();
  ctx.beginPath();ctx.moveTo(x+5,y+1);ctx.quadraticCurveTo(x+13,y+span(x)*.12,x+21,leafLocal(x+21,s)-span(x+21)*.08);ctx.stroke();
 }
 ctx.restore();}
const RADIUS=48;const outline=Array.from({length:160},(_,k)=>{const a=2*Math.PI*k/160;const sy=Math.sin(a);return [45*Math.cos(a)*(1-.23*Math.max(0,sy)),54*sy+3*Math.max(0,sy)**3];});
// Approximate no-slip roll phase integrates the non-round silhouette's support radius.
const rollAngles=new Float64Array(541);rollAngles[540]=5.50;
for(let k=539;k>=0;k--){const a=rollAngles[k+1],c=Math.cos(a),z=Math.sin(a);let radius=1;for(const[x,y]of outline)radius=Math.max(radius,x*z+y*c);rollAngles[k]=a-1/radius;}
function rollAngle(rel){const f=clamp(rel+435,0,540),i=Math.min(539,Math.floor(f));return mix(rollAngles[i],rollAngles[i+1],f-i);}
function supportAt(wx,s){
 const left=s.rootX+Math.cos(s.theta)*(-500)-Math.sin(s.theta)*leafLocal(-500,s);
 const onLeaf=wx>=left && wx<=s.rootX;
 const leafY=onLeaf?leafSurface(wx,s):Infinity,soilY=wx>=1050?groundY(wx):Infinity;
 return leafY<soilY?{y:leafY,kind:'leaf'}:{y:soilY,kind:'soil'};
}
function seedPose(t,s){const q=t>=16?state(16):s;const x=q.rootX+q.rel;const angle=rollAngle(q.rel);const c=Math.cos(angle),z=Math.sin(angle);let y=Infinity,contactX=0,contactKind='leaf',contactY=0;for(const[a,b]of outline){const dx=a*c-b*z,dy=a*z+b*c;const wx=x+dx;const support=supportAt(wx,q);const cy=support.y-dy;if(cy<y){y=cy;contactX=wx;contactKind=support.kind;contactY=support.y;}}
 return {x,y,angle,contactX,contactY,contactKind};}
function drawSeed(t,s,p){
 // A restrained contact patch tells the viewer what currently carries the seed.
 ctx.save();ctx.translate(p.contactX,p.contactY+1);ctx.scale(1,.23);let g=ctx.createRadialGradient(0,0,0,0,0,15);g.addColorStop(0,'rgba(42,31,22,.28)');g.addColorStop(1,'rgba(42,31,22,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,15,0,Math.PI*2);ctx.fill();ctx.restore();
 ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.angle);
 const shape=()=>{ctx.moveTo(...outline[0]);for(const p of outline.slice(1))ctx.lineTo(...p);ctx.closePath();};
 g=ctx.createLinearGradient(-44,-30,44,40);g.addColorStop(0,'#c5844d');g.addColorStop(.45,'#a76337');g.addColorStop(1,'#6e3828');silhouette(shape,g,2);
 ctx.save();ctx.beginPath();shape();ctx.clip();ctx.beginPath();ctx.moveTo(-55,-65);ctx.lineTo(55,-65);ctx.lineTo(55,-19);ctx.quadraticCurveTo(0,-3,-55,-19);ctx.closePath();ctx.fillStyle='#625437';ctx.fill();texture(1.1);
 ctx.strokeStyle='rgba(219,191,125,.42)';ctx.lineWidth=1.3;for(let row=0;row<4;row++){for(let k=0;k<8;k++){const x=-46+k*13+(row%2?6:0),y=-48+row*10;ctx.beginPath();ctx.moveTo(x-4,y-3);ctx.quadraticCurveTo(x,y+6,x+5,y-3);ctx.stroke();}}
 // Single fixed surface notch makes rotation and identity readable.
 ctx.strokeStyle='#292d24';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-13,-42);ctx.lineTo(-10,-25);ctx.stroke();ctx.restore();
 ctx.beginPath();ctx.moveTo(-30,14);ctx.bezierCurveTo(-26,30,-13,40,3,43);ctx.strokeStyle='rgba(224,154,87,.25)';ctx.lineWidth=1.1;ctx.stroke();ctx.restore();
}
function soilTrace(t,p){if(t<14)return;const pts=[];for(let tt=13.9;tt<=Math.min(t,16)+.00001;tt+=1/24){const q=seedPose(tt,state(tt));if(q.contactKind==='soil')pts.push([q.contactX,q.contactY+1.6]);}if(p.contactKind==='soil')pts.push([p.contactX,p.contactY+1.6]);if(pts.length<2)return;ctx.beginPath();ctx.moveTo(...pts[0]);for(const p of pts.slice(1))ctx.lineTo(...p);ctx.strokeStyle='rgba(61,40,28,.16)';ctx.lineWidth=2.3;ctx.stroke();}
function render(t){const s=state(t),p=seedPose(t,s);background(t);const wave=water(t,s);land(t);soilTrace(t,p);leaf(t,s);drawSeed(t,s,p);return {time:t,...s,seed:p,wave};}
const manifests=[],hashes=[];
let frames=mode==='preview'?[0,24,96,216,240,276,300,312,336,350,384,432,479]:mode==='probe'?Array.from({length:145},(_,i)=>240+i):Array.from({length:Number(args.end||479)-Number(args.start||0)+1},(_,i)=>Number(args.start||0)+i);
const folder=path.join(OUT,mode==='preview'?'preview':mode==='probe'?'probe':'frames');fs.mkdirSync(folder,{recursive:true});
const rawPath=path.join(OUT,'frames.rgba');if(mode==='raw')fs.writeFileSync(rawPath,Buffer.alloc(0));
for(const frame of frames){
 const s=render(frame/FPS);manifests.push(s);
 if(mode==='raw'){
  const pixels=Buffer.from(ctx.getImageData(0,0,W,H).data.buffer);fs.appendFileSync(rawPath,pixels);
  hashes.push({frame,sha256:crypto.createHash('sha256').update(pixels).digest('hex')});
  if(frame%24===0||[276,281,300,336,350,384,432,479].includes(frame))fs.writeFileSync(path.join(folder,`${String(frame).padStart(4,'0')}.png`),canvas.toBuffer('image/png'));
 }else fs.writeFileSync(path.join(folder,`${String(frame).padStart(4,'0')}.png`),canvas.toBuffer('image/png'));
 if(frame%24===0)process.stdout.write(`frame ${frame}\n`);
}
fs.writeFileSync(path.join(OUT,`${mode}-states.json`),JSON.stringify(manifests,null,2));
if(mode==='raw')fs.writeFileSync(path.join(OUT,'frame-hashes.json'),JSON.stringify(hashes,null,2));
