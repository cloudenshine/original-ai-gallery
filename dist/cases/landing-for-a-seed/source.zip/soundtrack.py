"""Original sound design. All tones and textures synthesized locally; no samples.
Writes separate music, water/foley and stereo master PCM WAV at 48 kHz.
"""
from pathlib import Path
import json
import numpy as np
from scipy import signal
from scipy.io import wavfile
R=Path(__file__).resolve().parent
SR=48000;D=20.;N=int(SR*D);T=np.arange(N)/SR;rng=np.random.default_rng(84217)
music=np.zeros((N,2));foley=np.zeros_like(music)
def pan(x,p=0):
 return np.column_stack((x*np.sqrt((1-p)/2),x*np.sqrt((1+p)/2)))
def put(dst,x,onset,p=0):
 k=round(onset*SR);x=pan(x,p);end=min(N,k+len(x));dst[k:end]+=x[:end-k]
def filtered_noise(length,low,high):
 x=rng.normal(size=length);s=signal.butter(3,[low,high],btype='bandpass',fs=SR,output='sos');x=signal.sosfilt(s,x)
 return x/(np.std(x)+1e-9)
def note(freq,dur,amp):
 t=np.arange(round(dur*SR))/SR
 # A softened wooden resonator: inharmonic partials fade faster than the body.
 x=sum(a*np.sin(2*np.pi*freq*r*t+p)*np.exp(-t/tau) for r,a,tau,p in [(1,1,1.15,0),(2.01,.25,.46,.3),(3.97,.08,.16,1.2),(7.08,.025,.06,2)])
 attack=1-np.exp(-t/.008);tail=np.minimum(1,np.maximum(0,(dur-t)/.18))
 return x*attack*tail*amp
for t,f,a,p in [(.5,329.6276,.074,-.14),(2.5,493.8833,.048,.11),(4.5,329.6276,.065,-.1),(6.2,493.8833,.044,.13),(7.1,329.6276,.036,-.04)]:
 put(music,note(f,min(2.1,8-t),a),t,p)
for f,a in [(130.8128,.075),(261.6256,.027),(329.6276,.024)]:put(music,note(f,3.8,a),16.2,-.04)
put(music,note(391.9954,3.2,.037),16.8,.1)
# Soft flowing bed. Independent channels are correlated but not identical.
for ch in range(2):
 low=filtered_noise(N,110,850);high=filtered_noise(N,900,3200)
 flow=.75+.12*np.sin(2*np.pi*.21*T+ch*.4)+.07*np.sin(2*np.pi*.63*T)
 foley[:,ch]+=.0085*low*flow+.0012*high
# Tiny asynchronous rivulet resonances, not periodic drops.
for onset in [1.8,3.1,5.7,8.7,10.85,12.1,17.8,19.0]:
 t=np.arange(int(.16*SR))/SR;f=rng.uniform(800,1350)
 x=.008*np.sin(2*np.pi*(f*t-1100*t*t))*np.exp(-t/.028)*(1-np.exp(-t/.0015))
 put(foley,x,onset,rng.uniform(-.4,.4))
def scrape(a,b,amp,low,high,p):
 n=round((b-a)*SR);t=np.arange(n)/SR;env=np.sin(np.pi*np.minimum(1,t/(b-a)))**1.4
 texture=filtered_noise(n,low,high);grains=.68+.2*np.sin(2*np.pi*31*t)+.12*np.sin(2*np.pi*73*t+.6)
 put(foley,texture*env*grains*amp,a,p)
def touch(onset,amp,frequency,duration=.14,p=0):
 t=np.arange(round(duration*SR))/SR
 body=np.sin(2*np.pi*frequency*t)*np.exp(-t/.035)
 grain=filtered_noise(len(t),350,2100)*np.exp(-t/.012)*.23
 env=1-np.exp(-t/.0012)
 put(foley,(body+grain)*env*amp,onset,p)
scrape(.25,1.4,.019,650,4200,-.1);touch(1.35,.039,340,p=-.12);scrape(1.4,1.7,.018,900,5500,-.12)
scrape(10,10.6,.026,180,1300,.13)
scrape(11.5,13,.012,130,1500,-.15)
scrape(11.7,12.3,.006,700,2200,-.10)
scrape(12.5,14.6,.032,450,3600,.04)
scrape(14,16,.025,90,900,.18);touch(14.6,.052,118,duration=.22,p=.18)
scrape(16.05,17.7,.009,100,1450,-.1)
# Rolling texture breaks into quiet, increasingly separated soil contacts.
for onset,amp in [(14.22,.014),(14.46,.017),(14.72,.013),(15.04,.010),(15.42,.007)]:touch(onset,amp,160,duration=.08,p=.18)
master=music+foley
fade=np.minimum(1,np.minimum(T/.01,(D-T)/.01));master*=fade[:,None];music*=fade[:,None];foley*=fade[:,None]
# Fixed conservative gain, no clipping or loudness-based substitute for listening.
gain=.84/max(np.max(np.abs(master)),1e-9);master*=gain;music*=gain;foley*=gain
out=R/'output';out.mkdir(exist_ok=True)
for name,x in [('music',music),('foley',foley),('master',master)]:wavfile.write(out/f'{name}.wav',SR,np.round(np.clip(x,-1,1)*32767).astype(np.int16))
(out/'audio-measurements.json').write_text(json.dumps({'sample_rate':SR,'samples_per_channel':N,'duration_seconds':D,'channels':2,'sample_peak_dbfs':float(20*np.log10(np.max(np.abs(master)))),'rms_dbfs':float(20*np.log10(np.sqrt(np.mean(master**2)))),'original_synthesis':True,'actual_listening':'not yet performed','technical_checks_do_not_replace_listening':True},indent=2))
