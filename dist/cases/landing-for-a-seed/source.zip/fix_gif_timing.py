"""Normalize a 240-frame derived GIF to exactly 20 seconds, without touching pixels."""
from pathlib import Path
import sys
p=Path(sys.argv[1]);data=bytearray(p.read_bytes());assert data[:6] in (b'GIF87a',b'GIF89a')
pos=13
if data[10]&128:pos+=3*(2**((data[10]&7)+1))
gces=[];frames=0
def skip_blocks(pos):
 while data[pos]:pos+=1+data[pos]
 return pos+1
while pos<len(data):
 marker=data[pos]
 if marker==0x3b:break
 if marker==0x21:
  label=data[pos+1]
  if label==0xf9:
   assert data[pos+2]==4;gces.append(pos+4)
  pos=skip_blocks(pos+2)
 elif marker==0x2c:
  packed=data[pos+9];pos+=10
  if packed&128:pos+=3*(2**((packed&7)+1))
  pos+=1;pos=skip_blocks(pos);frames+=1
 else:raise ValueError(f'Unexpected GIF block {marker:#x} at {pos}')
assert frames==len(gces)==240,(frames,len(gces))
for i,loc in enumerate(gces):data[loc:loc+2]=[8,8,9][i%3].to_bytes(2,'little')
p.write_bytes(data)
print('240 frames; 8/8/9-centisecond timing; total 20 seconds; pixels unchanged')
