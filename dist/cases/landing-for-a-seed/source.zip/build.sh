#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
node render.cjs --mode=raw
python3 soundtrack.py
ffmpeg -y -v error -f rawvideo -pixel_format rgba -video_size 1280x720 -framerate 24 -i output/frames.rgba -i output/master.wav -frames:v 480 -t 20 -c:v libx264 -preset slow -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart output/film.mp4
ffmpeg -y -v error -i output/film.mp4 -filter_complex "[0:v]select='not(mod(n,2))',setpts=N/(12*TB),scale=640:360:flags=lanczos,split[a][b];[a]palettegen=max_colors=192[p];[b][p]paletteuse=dither=bayer:bayer_scale=3" -loop 0 output/preview.gif
python3 fix_gif_timing.py output/preview.gif
