#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p qa native-frames composite audio
blender -b -t 8 --python src/scene.py > qa/scene-build.log 2>&1
blender -b the-weight-we-share.blend -t 8 --python src/render_frames.py > qa/render.log 2>&1
blender -b the-weight-we-share.blend --python src/clean_blend.py > qa/clean-blend.log 2>&1
blender -b the-weight-we-share.blend --python src/check_scene.py > qa/scene-check.log 2>&1
python3 src/sound.py
ffmpeg -hide_banner -y -i audio/mix-raw.wav -af loudnorm=I=-16:TP=-1.8:LRA=9:print_format=json -ar 48000 audio/mix.wav 2> qa/loudnorm.log
for stem in music foley room mix; do ffmpeg -hide_banner -loglevel error -y -i audio/$stem.wav -c:a flac audio/$stem.flac; done
python3 src/overlay.py
ffmpeg -hide_banner -y -framerate 12 -i composite/%04d.png -i audio/mix.wav -vf 'hqdn3d=1.0:1.0:2.5:2.5,fps=24' -c:v libx264 -crf 17 -preset medium -pix_fmt yuv420p -c:a aac -b:a 256k -ar 48000 -t 26 -movflags +faststart film.mp4
ffmpeg -hide_banner -y -ss 23 -i film.mp4 -frames:v 1 -q:v 2 poster.jpg

python3 src/verify_media.py
