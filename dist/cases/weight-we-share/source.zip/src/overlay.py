"""Typesetting over genuine Blender renders. No picture synthesis or editing."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json,sys
ROOT=Path(__file__).resolve().parents[1];W,H=1280,720
fonts=ROOT/'assets'
reg=lambda s:ImageFont.truetype(str(fonts/'NotoSansSC-Regular.otf'),s)
bold=lambda s:ImageFont.truetype(str(fonts/'NotoSansSC-Bold.otf'),s)
text_cues=[(.8,4.5,'石拱，先由支架托住。'),(5.2,8,'撤下支架。'),(12.2,15.8,'相邻石块挤压，传递重量。'),(16,20,'两侧支承抵住拱向外的推力。'),(22,26,'拱与两侧支承，共同承重。')]

def typeset(im,t):
 im=im.convert('RGBA');ov=Image.new('RGBA',(W,H));d=ImageDraw.Draw(ov)
 # Quiet editorial frame: the real 3D object keeps the visual centre.
 d.text((48,34),'借力',font=bold(38),fill=(235,232,218,255))
 d.text((48,86),'THE WEIGHT WE SHARE',font=reg(13),fill=(174,184,185,255))
 d.line((48,118,95,118),fill=(184,139,66,255),width=2)
 label='构造示意 · 非工程仿真';bbox=d.textbbox((0,0),label,font=reg(16));d.text((W-48-(bbox[2]-bbox[0]),42),label,font=reg(16),fill=(186,192,190,255))
 phases=[(0,5,'01  /  暂时的托举'),(5,12,'02  /  留出空隙'),(12,20,'03  /  彼此与两端'),(20,26,'04  /  空处，是结果')]
 for a,b,txt in phases:
  if a<=t<b:d.text((48,612),txt,font=reg(16),fill=(183,156,110,255))
 # A local dark gradient protects subtitles without hiding the support geometry.
 for y in range(645,H):d.line((0,y,W,y),fill=(7,15,19,round((y-645)/(H-645)*190)))
 for a,b,txt in text_cues:
  if a<=t<b:
   f=reg(28);box=d.textbbox((0,0),txt,font=f);d.text(((W-(box[2]-box[0]))/2,650),txt,font=f,fill=(239,239,227,255))
 if t>=24:d.text((W-170,610),'意美浮云',font=reg(20),fill=(198,200,187,255))
 return Image.alpha_composite(im,ov).convert('RGB')
if __name__=='__main__':
 out=ROOT/'composite';out.mkdir(exist_ok=True)
 if '--stills' in sys.argv:
  for p in (ROOT/'qa').glob('style-*.png'):
   t=float(p.stem.split('-')[-1]);typeset(Image.open(p),t).save(ROOT/'qa'/('review-'+p.name))
 else:
  for i,p in enumerate(sorted((ROOT/'native-frames').glob('*.png'))):
   typeset(Image.open(p),i/12).save(out/p.name)
  print('composited',i+1,'frames')
 # SRT timing matches the fixed event clock; no transcription claims.
 def ts(x):
  z=round(x*1000);return f'{z//3600000:02}:{z//60000%60:02}:{z//1000%60:02},{z%1000:03}'
 (ROOT/'subtitles.srt').write_text('\n\n'.join(f'{i+1}\n{ts(a)} --> {ts(b)}\n{txt}' for i,(a,b,txt) in enumerate(text_cues))+'\n')
