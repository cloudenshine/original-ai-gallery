"""Original Blender scene. Procedural geometry/materials. Not a structural simulation."""
import bpy, math, os, sys, json, random
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
FPS=24; DUR=26; W=1280; H=720
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene
s.render.engine='CYCLES';s.cycles.samples=int(os.getenv('SAMPLES','16'));s.cycles.use_denoising=False
s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.15;s.cycles.adaptive_min_samples=4
s.cycles.max_bounces=2;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=1
s.render.resolution_x=W;s.render.resolution_y=H;s.render.resolution_percentage=100
s.render.fps=FPS;s.frame_start=1;s.frame_end=FPS*DUR
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8'
s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast';s.view_settings.exposure=.2
s.world=bpy.data.worlds.new('Ink studio world');s.world.use_nodes=True
s.world.node_tree.nodes['Background'].inputs[0].default_value=(.06,.085,.12,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.22
s.render.film_transparent=False
s.render.threads_mode='FIXED';s.render.threads=8
# No absolute asset references: every surface is generated locally.
def mat(name,color,rough=.6,metal=0,stone=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF')
 p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 if stone:
  tc=n.new('ShaderNodeTexCoord');noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=85;noise.inputs['Detail'].default_value=2.5;noise.inputs['Roughness'].default_value=.75;l.new(tc.outputs['Object'],noise.inputs['Vector'])
  bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.22;bump.inputs['Distance'].default_value=.022;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],p.inputs['Normal'])
  ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.2;ramp.color_ramp.elements[0].color=tuple(v*.63 for v in color)+(1,);ramp.color_ramp.elements[1].position=.8;ramp.color_ramp.elements[1].color=tuple(min(1,v*1.18) for v in color)+(1,)
  l.new(noise.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs['Color'],p.inputs['Base Color'])
 return m
stone=[mat('Limestone_%02d'%i,(.59+i*.014,.54+i*.013,.44+i*.012),.76,stone=True) for i in range(5)]
base=mat('Abutment limestone',(.33,.305,.26),.74,stone=True)
brass=mat('Satin brass',(.52,.30,.095),.3,.78)
ink=mat('Ink plinth',(.016,.026,.034),.62)
black=mat('Mechanism charcoal',(.022,.028,.032),.38,.5)
ground=mat('Studio floor',(.025,.038,.046),.72)
def finish(o,name,m,bev=0):
 o.name=name;o.data.materials.append(m)
 if bev:
  mod=o.modifiers.new('Fine material edge','BEVEL');mod.width=bev;mod.segments=3
  mod=o.modifiers.new('Weighted face normals','WEIGHTED_NORMAL');mod.keep_sharp=True;mod.weight=50
 return o
def cube(name,loc,scale,m,bev=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,m,bev)
def cylinder(name,a,b,r,m):
 a,b=Vector(a),Vector(b);v=b-a
 bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=r,depth=v.length,location=(a+b)/2);o=bpy.context.object;o.rotation_euler=v.to_track_quat('Z','Y').to_euler();return finish(o,name,m,.006)
def sector(name,r0,r1,a,b,z,y,depth,m,bev=.014,n=8):
 vs=[]
 for yy in [y-depth/2,y+depth/2]:
  for r in [r0,r1]:
   for j in range(n+1):
    ang=a+(b-a)*j/n;vs.append((r*math.cos(ang),yy,z+r*math.sin(ang)))
 L=n+1;fs=[]
 for j in range(n):
  fs.extend([(j,j+1,L+j+1,L+j),(2*L+j,3*L+j,3*L+j+1,2*L+j+1),(j,2*L+j,2*L+j+1,j+1),(L+j,L+j+1,3*L+j+1,3*L+j)])
 fs.extend([(0,L,3*L,2*L),(n,2*L+n,3*L+n,L+n)])
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(vs,[],fs);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
 return finish(o,name,m,bev)
# Exhibit and feet.
cube('Exhibit plinth',(0,0,-.16),(7.7,4.3,.32),ink,.12)
cube('Ground',(0,0,-.40),(200,200,.15),ground,.0)
for sign in [-1,1]:
 x=sign*2.275
 cube(('Left' if sign<0 else 'Right')+' abutment',(x,0,.65),(1.05,1.34,1.3),base,.035)
 cube('Foot plinth '+str(sign),(x,0,.075),(1.25,1.50,.15),stone[1],.035)
 for j in range(3):
  # Thin incised front bedding grooves are geometry, not a screen-space texture.
  cube('Abutment joint '+str(sign)+' '+str(j),(x,-.675,.33+j*.29),(.95,.006,.011),ink,.001)
# 15 solid touching voussoirs, no single magic keystone.
for i in range(15):
 sector('Voussoir %02d'%(i+1),1.75,2.35,i*math.pi/15,(i+1)*math.pi/15,1.3,0,1.1,stone[(i*3)%5])
# Temporary brass centering: crown ring, spokes, base and telescopic columns.
bpy.ops.object.empty_add(type='PLAIN_AXES');carrier=bpy.context.object;carrier.name='Temporary centering moving frame'
def movable(o):o.parent=carrier;return o
movable(sector('Brass centering arch',1.64,1.745,0,math.pi,1.3,0,.38,brass,.008,72))
movable(cube('Centering tie',(0,0,1.29),(3.40,.32,.10),brass,.014))
for i in range(1,6):
 ang=i*math.pi/6
 movable(cylinder('Centering rib %d'%i,(0,0,1.3),(1.67*math.cos(ang),0,1.3+1.67*math.sin(ang)),.034,brass))
movable(cylinder('Centering hub',(0,-.22,1.3),(0,.22,1.3),.105,brass))
pistons=[];cranks=[]
for x in [-1.0,1.0]:
 cube('Jack foot '+str(x),(x,0,.07),(.44,.62,.14),black,.04)
 cylinder('Fixed jack tube '+str(x),(x,0,.1),(x,0,.27),.08,black)
 pistons.append(cylinder('Retracting piston '+str(x),(x,0,.25),(x,0,1.25),.049,brass))
 # Disc on the fixed sleeve hints at the lowering mechanism.
 cylinder('Jack collar '+str(x),(x,0,.23),(x,0,.28),.17,brass)
 bpy.ops.object.empty_add(location=(x,0,.29));crank=bpy.context.object;crank.name='Jack crank '+str(x);cranks.append(crank)
 handle=cylinder('Visible crank bar '+str(x),(x,-.26,.29),(x,.26,.29),.026,brass);handle.parent=crank;handle.matrix_parent_inverse=crank.matrix_world.inverted()
# No luminous arrows: only a broad real light reveals joints.
def area(name,loc,power,color,size,target):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.color=color;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();return o
area('Warm key',(-4,-5,8),1250,(1,.88,.72),5,(0,0,1.8))
area('Cool contour',(4,3,6),1700,(.68,.80,1),4,(0,0,1.6))
area('Front soft fill',(1,-7,3.5),260,(.86,.91,1),4,(0,0,1.8))
sweep=area('Material revealing side light',(-5,-1,4),0,(1,.78,.49),3,(0,0,2.0))
# Single active camera with explicit cuts at 12s, 16s and 20s.
bpy.ops.object.camera_add(location=(5.3,-11.8,5.0));cam=bpy.context.object;cam.name='Director camera';s.camera=cam;cam.data.lens=48;cam.data.clip_end=300
cam.data.dof.use_dof=False

def ease(x):x=max(0,min(1,x));return x*x*x*(x*(x*6-15)+10)
def lerp(a,b,u):return tuple(x+(y-x)*u for x,y in zip(a,b))
def state(t):
 if t<5:
  u=ease(t/5);loc=lerp((5.2,-11.8,5.0),(2.1,-12.7,4.8),u);target=(0,0,1.55);lens=48
 elif t<12:loc=(2.1,-12.7,4.8);target=(0,0,1.55);lens=48
 elif t<16:
  u=ease((t-12)/4);loc=lerp((-4.0,-6.2,4.7),(-3.7,-6.3,4.65),u);target=(-.94,0,2.6);lens=59
 elif t<20:
  loc=(2.1,-12.7,4.8);target=(0,0,1.55);lens=48
 else:
  u=ease((t-20)/3);loc=lerp((4.0,-12.3,5.1),(5.2,-11.8,5.0),u);target=(0,0,1.55);lens=48
 return loc,target,lens,-.9*ease((t-5)/5.5)
# Bake per-frame transforms so the saved .blend plays without external handlers.
for f in range(1,FPS*DUR+1):
 t=(f-1)/FPS;loc,target,lens,z=state(t)
 cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=lens
 cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f);cam.data.keyframe_insert('lens',frame=f)
 carrier.location.z=z;carrier.keyframe_insert('location',frame=f)
 for crank in cranks:
  crank.rotation_euler.z=.4*ease((t-4)/.6);crank.keyframe_insert('rotation_euler',frame=f)
 for piston in pistons:
  piston.location.z=(.25+1.25+z)/2;piston.scale.z=1+z;piston.keyframe_insert('location',frame=f);piston.keyframe_insert('scale',frame=f)
 sweep.data.energy=220*ease((t-12)/1.2)*(1-ease((t-19)/1));sweep.data.keyframe_insert('energy',frame=f)
for a in bpy.data.actions:
 for fc in a.fcurves:
  for k in fc.keyframe_points:k.interpolation='CONSTANT'
s['work_title']='借力 / The Weight We Share';s['claim_boundary']='Illustrative keyframe animation, not engineering simulation';s['source_asset_policy']='Original procedural geometry/materials; no external assets'
s.render.filepath='//frames/'
s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'the-weight-we-share.blend'))
# Export geometric evidence independently readable without Blender.
geom={'engine':bpy.app.version_string,'renderer':'Cycles CPU','frames':624,'fps':24,'resolution':[W,H],'voussoirs':15,'archCenterZ':1.3,'intradosRadius':1.75,'ringOuterRadius':2.35,'supportTopZ':1.3,'centeringOuterRadius':1.745,'centeringLowering':.9,'simulation':False,'cameraCuts':[12,16,20]}
(ROOT/'qa/geometry.json').write_text(json.dumps(geom,indent=2))
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if '--stills' in args:
 for t in [0,5,9,11,13.5,17.5,23]:
  s.frame_set(int(t*FPS)+1);s.render.filepath=str(ROOT/'qa'/('style-%05.1f.png'%t));bpy.ops.render.render(write_still=True)
elif '--render' in args:
 s.render.filepath=str(ROOT/'frames'/'');bpy.ops.render.render(animation=True)
