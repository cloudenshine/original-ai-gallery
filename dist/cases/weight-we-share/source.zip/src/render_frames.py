"""Render on twos; exact static camera/object/light states are reused byte-for-byte."""
import bpy,sys,shutil,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];s=bpy.context.scene
s.cycles.samples=16;s.cycles.max_bounces=2;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=1
s.cycles.adaptive_threshold=.15;s.cycles.adaptive_min_samples=4;s.cycles.use_denoising=False
s.render.threads_mode='FIXED';s.render.threads=8;s.render.fps=24
s.render.filepath='//native-frames/'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'the-weight-we-share.blend'))
out=ROOT/'native-frames';out.mkdir(exist_ok=True);cache={};rows=[];started=time.time()
for idx,f in enumerate(range(1,625,2),1):
 s.frame_set(f)
 key=tuple(round(v,7) for o in bpy.data.objects for v in [*o.location,*o.rotation_euler,*o.scale])+tuple(round(l.energy,7) for l in bpy.data.lights)+tuple(round(c.lens,7) for c in bpy.data.cameras)
 p=out/f'{idx:04}.png';reused=False
 if key in cache:
  if not p.exists():shutil.copy2(cache[key],p)
  reused=True
 elif not p.exists():
  s.render.filepath=str(p);bpy.ops.render.render(write_still=True)
 cache[key]=p;rows.append({'native_frame':idx,'scene_frame':f,'time':(f-1)/24,'reused':reused})
 (ROOT/'qa/render-progress.json').write_text(json.dumps({'completed':idx,'target':312,'unique_states_so_far':len(cache),'elapsed_seconds':time.time()-started}))
(ROOT/'qa/render-receipt.json').write_text(json.dumps({'engine':bpy.app.version_string,'renderer':'Cycles CPU','samples':16,'bounces':2,'native_fps':12,'native_frames':312,'encoded_fps':24,'encoded_frames':624,'unique_render_states':len(cache),'elapsed_seconds':time.time()-started,'frames':rows},indent=2))
print('RENDER_COMPLETE',len(rows),len(cache),time.time()-started)
