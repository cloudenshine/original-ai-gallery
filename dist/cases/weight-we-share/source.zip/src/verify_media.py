from pathlib import Path
import subprocess,json,hashlib,sys,zipfile
from scipy.io import wavfile
import numpy as np
R=Path(__file__).resolve().parents[1]
def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-count_frames','-of','json',str(p)]))
p=probe(R/'film.mp4');v=next(s for s in p['streams'] if s['codec_type']=='video');a=next(s for s in p['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'])==(1280,720)
assert v['avg_frame_rate']=='24/1' and int(v['nb_read_frames'])==624
assert a['sample_rate']=='48000' and a['channels']==2
assert abs(float(p['format']['duration'])-26)<.05
subprocess.run(['ffmpeg','-v','error','-i',str(R/'film.mp4'),'-f','null','-'],check=True,capture_output=True)
frames=sorted((R/'native-frames').glob('*.png'));assert [f.name for f in frames]==[f'{i:04}.png' for i in range(1,313)]
receipt=json.loads((R/'qa/render-receipt.json').read_text());assert receipt['native_frames']==312
assert not json.loads((R/'qa/scene-check.json').read_text())['failures']
# Decode each published lossless stem and verify PCM against the generated master.
stems=[]
for name in ['music','foley','room','mix']:
 pth=R/'audio'/f'{name}.flac';raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(pth),'-f','s16le','-'])
 sr,original=wavfile.read(R/'audio'/f'{name}.wav');assert raw==original.astype('<i2').tobytes()
 stems.append({'name':name,'pcm_identical':True,'frames':len(original),'sample_rate':sr,'peak':int(np.abs(original.astype(np.int32)).max())})
summary={k:receipt[k] for k in ['engine','renderer','samples','bounces','native_fps','native_frames','encoded_fps','encoded_frames']}
summary['distinct_final_image_files']=len({hashlib.sha256(f.read_bytes()).hexdigest() for f in frames})
summary['camera_cuts_seconds']=[12,16,20]
(R/'qa/render-summary.json').write_text(json.dumps(summary,indent=2))
out={'video':{'codec':v['codec_name'],'width':v['width'],'height':v['height'],'rate':v['avg_frame_rate'],'decoded_frames':int(v['nb_read_frames'])},'audio':{'codec':a['codec_name'],'sample_rate':a['sample_rate'],'channels':a['channels']},'duration':p['format']['duration'],'full_file_decode':'passed','source_stem_roundtrip':stems,'render':summary,'complete_realtime_viewing':'not_completed','subjective_listening':'not_completed'}
(R/'qa/media.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
