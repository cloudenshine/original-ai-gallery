import bpy,json,math
from pathlib import Path
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector
R=Path(__file__).resolve().parents[1];s=bpy.context.scene
rows=[];fail=[]
assert len([o for o in bpy.data.objects if o.name.startswith('Voussoir')])==15
support=[bpy.data.objects[n] for n in ['Left abutment','Right abutment']]
for f in range(1,625):
 s.frame_set(f);t=(f-1)/24
 if t<12 or t>=16:
  for o in support:
   pts=[world_to_camera_view(s,s.camera,o.matrix_world@Vector(p)) for p in o.bound_box]
   if not all(.015<p.x<.985 and .06<p.y<.94 for p in pts):fail.append([f,'support crop',o.name])
 z=bpy.data.objects['Temporary centering moving frame'].location.z
 # Entire centering frame has |x|<=1.745 while abutments begin at |x|=1.75.
 if z<-.900001 or z>.000001:fail.append([f,'lowering overshoot'])
 if t>=10.5 and abs(z+.9)>1e-6:fail.append([f,'late movement'])
 if 5<=t<12 and (s.camera.location-Vector((2.1,-12.7,4.8))).length>1e-5:fail.append([f,'camera moved during withdrawal'])
 for o in bpy.data.objects:
  if not all(math.isfinite(v) for v in [*o.location,*o.rotation_euler,*o.scale]):fail.append([f,'nonfinite',o.name])
 rows.append({'frame':f,'lowering':round(z,7)})
# No file-based resources are required by the blend.
external=[i.filepath for i in bpy.data.images if i.source=='FILE' and i.filepath]
report={'scene_frames_checked':624,'voussoir_count':15,'support_projection_checked':'all withdrawal frames and wide views','centering_horizontal_clearance_per_side':.005,'geometry_method':'analytic construction dimensions, no rigid-body/structural solver','external_images':external,'failures':fail}
(R/'qa/scene-check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));assert not fail
