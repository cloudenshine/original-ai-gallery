"""Original deterministic chamber-like score and mechanism Foley, no samples."""
from pathlib import Path
import json, numpy as np
from scipy import signal
from scipy.io import wavfile
ROOT=Path(__file__).resolve().parents[1];SR=48000;DUR=26;N=SR*DUR
rng=np.random.default_rng(620711);music=np.zeros((N,2));foley=np.zeros((N,2));air=np.zeros((N,2))
def add(bus,y,t,amp=1,pan=0):
 i=round(t*SR);j=min(N,i+len(y));y=y[:j-i]*amp
 if y.ndim==1:y=np.column_stack([y*np.sqrt((1-pan)/2),y*np.sqrt((1+pan)/2)])
 bus[i:j]+=y

def tone(freq,dur,kind='felt'):
 t=np.arange(round(dur*SR))/SR
 if kind=='bow':
  y=sum(np.sin(2*np.pi*freq*k*t + .008*np.sin(2*np.pi*.21*t))*1/(k*k) for k in range(1,6))
  env=np.minimum(1,t/1.4)*np.minimum(1,(dur-t)/2.0);return y*env
 y=sum(np.sin(2*np.pi*freq*r*t)*a*np.exp(-t/tau) for r,a,tau in [(1,1,1.4),(2,.24,.65),(2.76,.10,.24),(4.11,.04,.12)])
 return y*(1-np.exp(-t*120)) *np.minimum(1,(dur-t)/.15)
# First phrase suspends the fifth; second opens harmonic space; final resolution.
for start,dur,notes,amp in [(0.8,9.7,[73.416,110.0,164.814],.030),(11,11,[73.416,146.832,195.998,220],.025),(19.9,3.1,[73.416,146.832,174.614,220,293.665],.028)]:
 for k,f in enumerate(notes):add(music,tone(f,dur,'bow'),start,amp,(-1 if k%2==0 else 1)*.22)
for t,f,a,p in [(1.4,293.665,.07,-.2),(3.0,329.628,.045,.2),(4.55,220,.05,-.1),(6.4,293.665,.045,.15),(8.2,329.628,.035,-.1),(11.35,146.832,.07,0),(13.1,293.665,.065,-.2),(14.6,261.626,.05,.2),(16.2,220,.05,-.15),(17.8,195.998,.045,.2),(20.0,146.832,.085,0),(20.3,293.665,.06,-.2),(20.7,440,.035,.2)]:
 add(music,tone(f,min(2.3,23-t)),t,a,p)
add(music,tone(55,3.5,'bow'),17.5,.015,0)
# Ensure narrative quiet after lowering, then end with the still object.
time=np.arange(N)/SR
mute=np.ones(N);mute[(time>=10.5)&(time<11)]=0;mute[time>=23]=0
for a,b in [(10.35,10.5),(22.5,23)]:
 q=(time>=a)&(time<b);mute[q]*=.5+.5*np.cos(np.pi*(time[q]-a)/(b-a))
music*=mute[:,None]
def metal(dur=.7):
 t=np.arange(round(dur*SR))/SR;return sum(np.sin(2*np.pi*f*t)*np.exp(-t/tau)*a for f,tau,a in [(840,.13,.7),(1340,.18,.4),(2235,.09,.2),(3580,.055,.1)])*(1-np.exp(-t*2400))
add(foley,metal(),.4,.1,-.15);add(foley,metal(.45),4,.055,0)
# Grain of metal sliding: bandlimited noise with a slow friction modulation.
d=5.5;t=np.arange(round(d*SR))/SR;n=rng.standard_normal(len(t));sos=signal.butter(3,[250,2900],btype='bandpass',fs=SR,output='sos');n=signal.sosfilt(sos,n)
env=np.minimum(1,t/.25)*np.minimum(1,(d-t)/.25)
y=(n*.12*(.6+.4*np.sin(2*np.pi*8*t)**2)+.025*np.sin(2*np.pi*(170*t-3*t*t)))*env
add(foley,y,5,.65,-.05)
# A stone-coloured, non-diegetic material punctuation at the cut, not a load test.
t=np.arange(round(.65*SR))/SR;n=signal.sosfilt(signal.butter(2,1700,fs=SR,output='sos'),rng.standard_normal(len(t)))
y=.15*n*np.exp(-t*23)+.3*np.sin(2*np.pi*182*t)*np.exp(-t*13)+.12*np.sin(2*np.pi*497*t)*np.exp(-t*21)
add(foley,y,12,.32,-.22)
# A very quiet room texture, excluding the half-second narrative silence.
room=signal.sosfilt(signal.butter(2,500,fs=SR,output='sos'),rng.standard_normal(N))*.0009
room[(time>=10.5)&(time<11)]=0;room[time>=23]=0
for i in range(2):air[:,i]=room
for bus in [music,foley]:
 dry=bus.copy()
 for delay,gain in [(.067,.14),(.113,.10),(.193,.05)]:
  k=round(delay*SR);bus[k:]+=dry[:-k,::-1]*gain
 bus[(time>=10.5)&(time<11)]=0;bus[time>=23]=0
mix=music+foley+air
(ROOT/'audio').mkdir(exist_ok=True)
for name,x in [('music',music),('foley',foley),('room',air),('mix-raw',mix)]:wavfile.write(ROOT/'audio'/f'{name}.wav',SR,np.int16(np.clip(x,-1,1)*32767))
(ROOT/'audio/cues.json').write_text(json.dumps({'sampleRate':SR,'duration':DUR,'events':[{'time':.4,'event':'metal touch'},{'time':4,'event':'mechanism pre-motion'},{'time':5,'end':10.5,'event':'centering slide'},{'time':10.5,'end':11,'event':'narrative quiet'},{'time':12,'event':'material cut punctuation, non-diegetic'},{'time':20,'end':23,'event':'harmonic resolution'},{'time':23,'end':26,'event':'digital silence'}]},indent=2))
