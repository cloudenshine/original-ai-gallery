"""Clear remembered file-picker directories, then save a relocatable deliverable."""
import bpy,os
from pathlib import Path
R=Path(__file__).resolve().parents[1]
for screen in bpy.data.screens:
 for area in screen.areas:
  for space in area.spaces:
   if space.type=='FILE_BROWSER' and space.params:
    try: space.params.directory=b'//';space.params.filename='the-weight-we-share.blend'
    except Exception: pass
bpy.context.scene.render.filepath='//native-frames/'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'the-weight-we-share.blend'),check_existing=False)
