"""Original deterministic additive / filtered-noise score synthesis. No sampled assets."""
import numpy as np, wave, subprocess
SR=32000

def hz(midi): return 440*2**((midi-69)/12)
def envelope(n,attack=.02,release=.2):
 e=np.ones(n);a=min(n,int(attack*SR));r=min(n,int(release*SR));e[:a]*=np.linspace(0,1,a);e[-r:]*=np.linspace(1,0,r) if r else 1;return e
class Score:
 def __init__(self,duration,seed):
  self.n=round(duration*SR);self.t=np.arange(self.n)/SR;self.bgm=np.zeros((self.n,2));self.sfx=np.zeros_like(self.bgm);self.rng=np.random.default_rng(seed);self.events=[]
 def add(self,track,start,signal,gain=.1,pan=0,label=None):
  a=round(start*SR); skip=max(0,-a); a=max(0,a);signal=signal[skip:min(len(signal),self.n-a+skip)];n=len(signal)
  if n<=0:return
  arr=getattr(self,track);arr[a:a+n,0]+=signal*gain*np.sqrt((1-pan)/2);arr[a:a+n,1]+=signal*gain*np.sqrt((1+pan)/2)
  if label:self.events.append({'stem':track,'time':start,'duration':n/SR,'label':label,'pan':pan})
 def note(self,start,duration,midi,gain=.08,pan=0,kind='felt',track='bgm',label=None):
  t=np.arange(round(duration*SR))/SR;f=hz(midi)
  if kind=='pad': y=sum(np.sin(2*np.pi*f*h*t+.12*h)*amp for h,amp in [(1,1),(2,.15),(3,.07)]);y*=envelope(len(t),min(.6,duration/3),min(.9,duration/3))
  elif kind=='glass':y=(np.sin(2*np.pi*f*t)+.24*np.sin(2*np.pi*f*2.003*t)+.08*np.sin(2*np.pi*f*4.013*t))*np.exp(-t*2.7)*envelope(len(t),.012,.2)
  elif kind=='wood':y=(np.sin(2*np.pi*f*t)+.18*np.sin(2*np.pi*f*4*t))*np.exp(-t/.55)*envelope(len(t),.008,.08)
  elif kind=='pluck':y=(np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*f*2*t)+.12*np.sin(2*np.pi*f*3*t))*np.exp(-t/.8)*envelope(len(t),.008,.2)
  elif kind=='soft':y=(np.sin(2*np.pi*f*t)+.18*np.sin(2*np.pi*f*2*t))*np.exp(-t/1.1)*envelope(len(t),.015,.2)
  else:y=(np.sin(2*np.pi*f*t)+.12*np.sin(2*np.pi*f*3*t))*np.exp(-t/1.3)*envelope(len(t),.025,.25)
  self.add(track,start,y,gain,pan,label)
 def noise(self,start,duration,gain,pan=0,kind='cloth',mod=None,label=None):
  n=round(duration*SR);w=self.rng.normal(size=n);window={'cloth':35,'rain':6,'roll':90,'paper':12}.get(kind,20);cs=np.r_[0,np.cumsum(w)];lp=(cs[window:]-cs[:-window])/window;lp=np.pad(lp,(0,window-1));y=lp*np.sqrt(window)*.45
  if kind=='paper': y=(w-lp)*.18
  y*=envelope(n,.07,.15)
  if mod is not None:y*=mod(np.arange(n)/SR+start)
  self.add('sfx',start,y,gain,pan,label)
 def band(self,n,lo,hi):
  w=self.rng.normal(size=n); z=np.fft.rfft(w); f=np.fft.rfftfreq(n,1/SR); mask=np.clip((f-lo)/max(30,lo*.2),0,1)*np.clip((hi-f)/max(30,hi*.2),0,1); y=np.fft.irfft(z*mask,n); return y/max(np.std(y),1e-9)*.33
 def save(self,directory):
  from pathlib import Path
  p=Path(directory);p.mkdir(parents=True,exist_ok=True)
  fade=envelope(self.n,.16,.55)[:,None]; self.bgm*=fade;self.sfx*=fade
  peak=np.max(abs(self.bgm+self.sfx));gain=min(1,.76/max(peak,1e-9));self.bgm*=gain;self.sfx*=gain
  metrics={}
  for stem in ['bgm','sfx']:
   v=getattr(self,stem);pcm=np.round(v*32767).astype('<i2');wav=p/(stem+'.wav')
   with wave.open(str(wav),'wb') as f:f.setparams((2,2,SR,0,'NONE','not compressed'));f.writeframes(pcm.tobytes())
   subprocess.run(['ffmpeg','-v','error','-y','-i',str(wav),'-c:a','flac',str(p/(stem+'.flac'))],check=True)
   dec=subprocess.check_output(['ffmpeg','-v','error','-i',str(p/(stem+'.flac')),'-f','s16le','-'])
   assert dec==pcm.tobytes();wav.unlink();metrics[stem]={'peak':float(np.max(abs(v))),'rms':float(np.sqrt(np.mean(v*v))),'samples':len(v),'flac_pcm_exact':True}
  metrics['mix_peak']=float(np.max(abs(self.bgm+self.sfx)));return metrics
