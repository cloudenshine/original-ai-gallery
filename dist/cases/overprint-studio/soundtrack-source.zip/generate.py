"""Reproducible derivative soundtrack generation; original synthesis, no network."""
from pathlib import Path
import numpy as np,json,subprocess,sys,math
from synthesis import Score,SR
IDS=['overprint-studio','night-transit','orbit-observatory','paper-city','prism-desk','rain-study','signal-letterpress','tidal-weave']
DURS=[12,20,24,20,10,12,10,20]
def mux(src,out):
 cmd=['ffmpeg','-v','error','-y','-i',str(src/'preview.mp4'),'-i',str(out/'bgm.flac'),'-i',str(out/'sfx.flac'),'-filter_complex','[1:a][2:a]amix=inputs=2:duration=longest:normalize=0[a]','-map','0:v','-map','[a]']
 if src.name=='rain-study' or (src/'event-score.json').exists() and json.loads((src/'event-score.json').read_text())['id']=='rain-study':
  cmd+=['-vf',"drawbox=x=48:y=589:w=300:h=18:color=0x263536:t=fill,drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf:text='PROCEDURAL RAIN / SOUND DESIGN':x=51:y=594:fontsize=9:fontcolor=0x9fafa5",'-c:v','libx264','-crf','18','-preset','medium','-pix_fmt','yuv420p']
 else:cmd+=['-c:v','copy']
 cmd+=['-c:a','aac','-b:a','160k','-movflags','+faststart',str(out/'demo.mp4')];subprocess.run(cmd,check=True)
def make(id):
 d=DURS[IDS.index(id)];s=Score(d,8471+IDS.index(id)*97);t=s.t
 def bed(at,until,notes,gain=.022,kind='pad'):
  for i,n in enumerate(notes):s.note(at,min(d-at,until-at+.12),n,gain,(i-(len(notes)-1)/2)*.08,kind,label='harmony '+str(notes))
 def melody(times,notes,gain=.055,kind='felt',tail=1.8):
  for at,n in zip(times,notes):s.note(at,min(tail,d-at),n,gain,0,kind,label='melody MIDI '+str(n))
 def band(a,b,lo,hi,gain,fn=None,pan=0,label=''):
  n=round((b-a)*SR);x=s.band(n,lo,hi);tt=np.arange(n)/SR+a
  e=np.minimum(np.clip((tt-a)/.12,0,1),np.clip((b-tt)/.12,0,1));x*=e
  if fn is not None:x*=fn(tt)
  s.add('sfx',a,x,gain,pan,label)
 def burst(q,length,lo,hi,gain,label,pan=0,tone=None):
  u=np.arange(round(length*SR))/SR;x=s.band(len(u),lo,hi);e=np.sin(np.pi*u/length)**2*np.exp(-3*u/length)
  if tone:x=x*.4+np.sin(2*np.pi*(tone[0]*u+(tone[1]-tone[0])*u*u/(2*length)))*.6
  s.add('sfx',q,x*e,gain,pan,label)
 if id=='overprint-studio':
  for a,b,ch in [(0,3,[48,55,57,62,64]),(3,6,[53,57,60,64]),(6,9,[45,55,60,64]),(9,10.5,[48,55,60,62]),(10.5,12,[48,55,57,60,64])]:bed(a,b,ch,.025,'pad')
  times=[0,.75,1.5,2.25,3,3.75,4.5,5.25,6,7.5,9,9.75,10.5,11.25];notes=[64,67,69,67,69,72,76,72,76,72,74,67,64,60]
  for a,n in zip(times,notes):melody([a],[n],.045 if 5<=a<9 else .07,'pluck',1.5)
  band(1,5,350,2200,.026,lambda x:.85+.15*np.sin(2*np.pi*3.1*x),label='Downward blue reveal; source printState 1<t<5')
  band(9,12,800,4200,.016,lambda x:.9+.1*np.sin(2*np.pi*2.3*x),label='Reverse paper wipe; source printState 9<t<12')
 elif id=='night-transit':
  chords=[[50,57,60,64,65],[46,53,57,62],[53,57,60,64],[48,55,62],[50,57,60,64,65]];pats=[[69,65,64,62],[65,62,57,60],[69,67,64,60],[67,62,64,67],[65,64,62,62]]
  for j,ch in enumerate(chords):bed(4*j,min(4*j+4,18.6666667),ch);melody([4*j+x for x in [0,2/3,2,8/3]],pats[j],.055,'soft')
  bed(18.6666667,20,[50,57,62,65]);L=165+145*2**.5+190+165*2**.5+335;u=(165+145*2**.5)/L
  for i in range(5):q=20*((u-i/5)%1);burst(q,.16,900,1800,.018,'Route0 dot '+str(i)+' passes node2 [400,355]',-1/3,(520,520))
 elif id=='orbit-observatory':
  for a,b,ch in [(0,6,[50,57,64]),(6,12,[45,52,59,62]),(12,18,[52,57,62,66]),(18,22,[50,57,64,66]),(22,24,[50,57,62])]:bed(a,b,ch,.026)
  melody([1,3,7,9,13,15,19,21,22],[81,76,83,81,78,76,81,76,74],.04,'soft',1.5)
  for q in [6,12,18]:
   a=q-.325;n=round(.65*SR);u=np.arange(n)/SR;x=s.band(n,700,3300)*np.sin(np.pi*u/.65)**2;phase=np.pi*q/12;worldx=600+125*np.cos(phase)*np.cos(-.68)-41*np.sin(phase)*np.sin(-.68);s.add('sfx',a,x,.012,np.clip((worldx/1200-.5)*2,-.5,.5),'Illustrative ring0 local-axis crossing at '+str(q))
 elif id=='paper-city':
  for a,b,ch in [(0,5,[53,57,60,62]),(5,10,[50,57,60,65]),(10,15,[46,53,57,62]),(15,55/3,[48,55,62,64]),(55/3,20,[53,57,60,62])]:bed(a,b,ch,.024)
  for j,ns in enumerate([[69,72,74],[77,76,72],[74,72,69],[67,64,65]]):melody([j*5+x for x in [0,5/3,10/3]],ns,.055,'felt',2)
  speed=np.abs(np.sin(np.pi*t/10));v=5*(1-np.cos(np.pi*t/10))/2-.5;x=600+(4.65-v)*71;pan=np.clip(x/1200,.25,.75);noise=s.band(s.n,100,900);freq=90+45*speed;tone=np.sin(2*np.pi*np.cumsum(freq)/SR);sig=(noise+.2*tone)*.012*speed**1.4;s.sfx[:,0]+=sig*np.cos(np.pi*pan/2);s.sfx[:,1]+=sig*np.sin(np.pi*pan/2);s.events.append({'stem':'sfx','time':0,'duration':20,'label':'Tram rolling follows |sin(pi*t/10)|^1.4 and screen x; zero at turnaround10'})
 elif id=='prism-desk':
  for n in [48,55,62,64,66,71]:
   temp=Score(d,0);temp.note(0,d,n,.026,0,'pad');v=temp.bgm
   if n in [64,66]:v*=np.interp(t,[0,2.5,5,7.5,8.5,10],[1,1.259,1,.708 if n==66 else 1,0 if n==66 else 1,0 if n==66 else 1])[:,None]
   elif n in [62,71]:v*=np.interp(t,[0,2.5,5,7.5,8.5,10],[1,1,1.259,.708 if n==71 else 1,0 if n==71 else 1,0 if n==71 else 1])[:,None]
   s.bgm+=v
  pulse=.5+.5*np.sin(np.pi*t/5);sig=sum(a*np.sin(2*np.pi*f*t) for f,a in [(1200,1),(1697,.25),(2399,.12)])*(.004+.010*pulse)*np.clip(t/.4,0,1);s.add('sfx',0,sig,1,0,'Illustrative shimmer follows source halo pulse, not ray activation');s.events.append({'stem':'bgm','time':0,'duration':10,'label':'C Lydian sustained voicing [48,55,62,64,66,71]; changing emphasis, no sequential ray notes'})
 elif id=='rain-study':
  for a,b,ch in [(0,3,[45,52,55,59,60]),(3,6,[41,48,52,55,57]),(6,9,[50,57,60,64,65]),(9,11,[45,52,55,59,60]),(11,12,[45,52,55,60])]:bed(a,b,ch,.017)
  melody([0,2,3,5,6,8,9,11],[64,60,57,55,65,64,60,57],.031,'felt',2)
  for pan in [-.6,.6]:band(0,12,350,7000,.018,lambda x:1+.04*np.sin(2*np.pi*.31*x),pan,'Synthesized rain bed, no field recording')
  for i in [5,7,8]:
   x=20+(i*137.91)%1160;q0=1.5*((.72-i*.61803398875)%1)
   for k in range(8):burst(q0+1.5*k,.15,700,4500,.01,'Visible rain drop '+str(i)+' contact p=.72',np.clip((x/1200-.5)*2,-.5,.5),(1000,600))
 elif id=='signal-letterpress':
  for a,b,ch in [(0,2.5,[48,55,57,64]),(2.5,5,[53,57,60,64]),(5,7.5,[52,55,60,62]),(7.5,9.375,[48,55,60,62]),(9.375,10,[48,55,60,64])]:bed(a,b,ch,.024)
  melody([0,.625,1.25,1.875,2.5,3.125],[64,67,69,72,69,67],.06,'pluck',1.5)
  melody([5,7.5,9.375],[64,62,60],.038,'pad',min(2,d-9.375))
  for a in [0,.625,1.25,1.875,2.5,3.125]:
   n=round(.03*SR);u=np.arange(n)/SR;x=s.band(n,900,5000)*np.sin(np.pi*u/.03)**2;x=x/max(abs(x))*.01259;s.add('bgm',a,x,1,0,'Quiet musical brush, not letter contact')
  for i in [3,10,16]:q=.045*i+2.7*(1-.01**.25);burst(q,.045,600,3000,.012,'Letter group end index '+str(i)+' reaches99% entry',0)
  band(8,10,700,3800,.012,lambda x:6*((x-8)/2)*(1-(x-8)/2),label='Paper return; smoothstep derivative r=(t-8)/2')
 elif id=='tidal-weave':
  for a,b,ch in [(0,5,[50,57,59,66]),(5,10,[43,50,54,59]),(10,15,[47,54,57,62]),(15,55/3,[45,50,54,59]),(55/3,20,[50,57,62,66])]:bed(a,b,ch,.023)
  ups=[[74,78,81],[71,74,69],[71,69,66],[76,78,74]];los=[[57,59,62],[55,57,59],[59,62,66],[57,54,62]]
  for j in range(4):
   melody([j*5+x for x in [0,5/3,10/3]],ups[j],.05,'wood',.65);offs=[5/6,2.5,25/6] if j<3 else [5/6,2.5];melody([j*5+x for x in offs],los[j],.048,'wood',.9)
  a=26.12;w=np.pi/10;p=w*t
  for u,lo,hi in [(2,300,1400),(6,500,1900),(10,800,2600)]:
   v=5;dx=a*w*np.cos(.5*v+p);dy=-a*w*np.cos(.42*u-p)+.28*a*w*np.cos(.6*v+.4*u+p);norm=np.sqrt(dx*dx+dy*dy)/(a*w*np.sqrt(1+1.28**2));x=252+u*58+a*np.sin(v*.5+p);pan=np.clip(x/1200,.25,.75);sig=s.band(s.n,lo,hi)*.004*norm**1.5;s.sfx[:,0]+=sig*np.cos(np.pi*pan/2);s.sfx[:,1]+=sig*np.sin(np.pi*pan/2);s.events.append({'stem':'sfx','time':0,'duration':20,'label':f'Cloth layer follows analytic speed of warp({u},5), not crossing impacts'})
 return s
if __name__=='__main__':
 if '--restore' in sys.argv:
  p=Path(sys.argv[sys.argv.index('--restore')+1]).resolve();mux(p,p);(p/'demo.mp4').rename(p/'restored-demo.mp4')
 elif '--regenerate' in sys.argv:
  id=sys.argv[sys.argv.index('--regenerate')+1];s=make(id);s.save(Path.cwd());print(json.dumps(s.events,indent=2))
 else:
  from package_case import ROOT,package
  for id in sys.argv[1:] or IDS:
   out=ROOT/'payload'/id;out.mkdir(parents=True,exist_ok=True);s=make(id);metrics=s.save(out);mux(ROOT.parent/'gallery-next/dist/cases'/id,out)
   subprocess.run(['ffmpeg','-v','error','-i',str(out/'demo.mp4'),'-f','null','-'],check=True)
   package(id,metrics,s.events);print(id,json.dumps(metrics),flush=True)
