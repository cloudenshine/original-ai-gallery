《月汐 TIDAL MEMORY》是一组原创图像编辑案例：先制作海玻璃玉兰与月海底图，再将它转化为具有立体出框效果的巴洛克画廊海报。参考来自 Evolink 提示库 Case 255。以下保留成品、底图、参考差异、完整实用提示和逐项验收，便于复用。

# 成品海报

![月汐 巴洛克出框画廊海报](artwork.png)

主海报为 1086 × 1448 像素，3:4，RGB PNG。标题为 TIDAL MEMORY，副句为 Where the sea remembers the moon.

# 原创底图

![月汐 海玻璃玉兰原创底图](source.png)

底图同为 1086 × 1448 像素，3:4，RGB PNG。两朵半透明玉兰与一个花苞在近景形成主次，右侧月海留白承接远岛、弯月和微弱暮光。没有使用参考作者的场景图作为生成输入。

# 参考与原创变化

直接参考：[Evolink Case 255 Baroque Winter Gallery Posters](https://github.com/Evolink-AI/awesome-gpt-image-2-6-prompts-and-api/blob/codex/gpt-image-2-5-prompts/cases/gpt-image-2-6.md#gpt-image-2-6-case-255)，作者来源为 [Goodmanprotocol 的公开作品](https://x.com/Goodmanprotocol/status/2118193088128745875)。已查看原例冬季村庄海报，核心关系是金色巴洛克框、灰泥墙、既有景物突破画框、下部原图缩略图与衬线排字。

本作保留上述空间与版式逻辑，将雪景村庄、暖灯、覆雪树枝换为原创月海、海玻璃玉兰和青灰雾色。出框物改为画中已有的前景花瓣，金框使用更克制的浅金磨损质地。标题、场景、主体材质、色彩系统和实际提示均为本次原创，没有复刻原例画面或复制其完整提示。

# 实测范围与模型说明

本次实际完成一次文生图和一次带底图的图像编辑，共两次生成，没有通过代码拼接伪装模型编辑。最终 PNG 是单幅生成结果。当前图像入口没有返回可核对的模型标识，不能宣称本作由 GPT Image 2.6、Sunburst 或 Flare 生成。

仓库将 Case 255 标为创作者自述的 GPT Image 2.6 作品，未披露变体、参数或重试次数，不等于独立基准。OpenAI 当前[图像提示指南](https://developers.openai.com/api/docs/guides/image-prompting)另有 2.6 Flare 与 Sunburst 的生成、编辑和格式说明。本作仅验证当前入口的参考图编辑、场景主要元素保留、材质表现与图文排版，没有测试 GIF、SVG、显式 markup 或不同模型对照。

# 质量检查

| 检查点 | 实际结果 |
|---|---|
| 构图和交付规格 | 两张文件均可解码，1086 × 1448，比例精确为 3:4。金框完整，周围留有墙面。 |
| 场景一致性 | 两朵开放玉兰、一个花苞、深色枝干、右侧远岛与右上弯月均保留，主体相对关系可辨认。 |
| 立体出框 | 前景左侧花瓣跨越金框并投影到墙面，上方花瓣与内框形成遮挡；没有增加新的装饰物。 |
| 材质与光 | 玻璃花瓣透光、金框磨损、灰泥颗粒和水纹具区别，光线总体来自左上，金属高光受控。 |
| 精确文字 | 人工逐字检查：TIDAL MEMORY 与 Where the sea remembers the moon. 拼写和句点正确。 |
| 版式 | 墙面连贯，没有白带、分隔线或拼版裂缝；标题和缩略图未碰撞。 |
| 需保留的局限 | 这是生成式重构，不是像素级保真；海报内景和缩略图有比例及局部细节变化。原提示希望同时突破左下外框，实际主要实现左侧突破，底部更接近遮挡与光影延伸。 |
| 适用范围 | 适合屏幕展示、社交海报和创意概念展示。现有分辨率不应称为大幅印刷母版。 |

整体判断：作为一个原创的巴洛克画廊海报案例，视觉完成度与核心风格对应成立。主要不足是生成式编辑无法保证细部和缩略图逐像素不变，因此不把它当作精准修图或产品保真测试。

# 完整底图提示

```text
Create one original fine-art image, portrait 3:4. This will be the source artwork for a later gallery-poster transformation, so deliver just the scene edge-to-edge, no frame, no text.

Title for internal art direction: TIDAL MEMORY. A luminous, sculptural branch of translucent sea-glass magnolia blossoms rises from an utterly still tidal pool at blue hour. Three blossoms only: one large half-open bloom in the left foreground, one smaller bloom reaching diagonally upward into the left third, and one bud near the stem. The petals are handblown milky opal glass, paper-thin at their irregular edges, with pale celadon and a trace of blush. Their material feels crafted and tactile, not plastic or jewelry. A slender dark bronze branch arcs organically from the lower-left water toward the upper-left. The largest bloom and its two long outer petals sit close to the bottom-left edge, making a strong foreground silhouette suitable for a later out-of-frame extension.

The middle and right two-thirds are quiet open water and mist. A thin crescent moon hangs above the right third. One very distant low island, faded to blue-grey, gives scale without competing. Water has a gentle ring of ripples near the stem, soft broken reflections, realistic glass caustics, almost imperceptible silver sea mist. Near the horizon a narrow warm pearl light fades into a dusky muted ultramarine sky.

The feeling is contemplative, spacious, delicately uncanny. Fine art photographic realism with the atmosphere of a patiently made still-life, subtle matte film tonality and exquisite material detail. Restrained celadon, ivory, slate blue, muted bronze. Large areas of negative space. Side light from high left softly catches petal edges; moonlight stays very faint. Coherent shadows and reflections, controlled highlights with no blown-out whites. Museum-quality composition, visual hierarchy and depth, naturally sharp foreground and soft atmospheric distance.

Avoid saturated teal-orange grading, fantasy castles, stars, scattered decorative objects, people, butterflies, extra flowers, crystal clusters, generic magical sparkles, watermarks, borders, signatures and all lettering.
```

# 完整编辑提示

编辑输入：上述原创底图。透明背景关闭。没有设置或声称工具未暴露的模型、seed、complexity 或质量参数。

```text
Use the attached original artwork as the sole scene reference and the edit target. Make one extraordinary 3:4 portrait gallery poster titled TIDAL MEMORY. This is a transformation of this exact image, not a newly invented scene.

LAYOUT: one continuous muted blue-slate plaster wall, natural shallow side lighting. Upper 76 percent: a substantial rectangular antique pale-gold Baroque frame surrounds this exact sea-glass magnolia and moonlit tidal scene. Frame outer bounds approximately x 10–90%, y 5–74%. Its ornament is carefully carved, refined acanthus relief with subtle rubbed gilding and dark recessed patina, realistic museum craftsmanship rather than glossy plastic. Keep the whole frame visible with generous wall margin.

PRESERVE THE ART: retain the two open translucent magnolia blossoms, single bud, dark bronze branch, distant island on the right, crescent moon in the upper right, tranquil sea and their relative composition. The image inside the frame should be recognizably the provided artwork with its quiet ivory/celadon/blush palette and silver-blue light. Do not add elements inside the original scene. Translate to a beautifully detailed photographic fine-art print, not a cartoon.

THE ONE SURREAL GESTURE: bring the large lower-left magnolia bloom subtly into real three-dimensional space in front of the frame. Its foreground petals overlap the lower-left inner gold rail and extend a little past the outer left and lower frame edges, retaining their connected original structure. One upper-left blossom petal may overlap the inner left rail. Give these existing glass petals softly directional cast shadows on the gilding and plaster, delicate transmission, and convincing scale. The sea remains fully contained inside the frame, and there is no dripping water or extra decoration. Glass is luminous without glow effects.

LOWER 24 PERCENT: continue the same wall with no separator. Include a small exact-looking thumbnail of the provided unedited source image at lower left, around x 12–27%, y 80–95%, not a different image. It has no white border, only a very soft natural shadow. Beside it put the exact two-word title "TIDAL MEMORY" in dignified, fine high-contrast uppercase serif lettering, pale warm ivory, neatly kerned. Beneath the title put this exact sentence in small elegant italic serif: "Where the sea remembers the moon." Both lines must be fully legible and spelled exactly. Fit within the right-hand space without crowding. No other text.

Art direction: quiet luxury, lyrical but restrained, a cohesive editorial art object. Controlled gold highlights, believable wall grain, subtle tactile finish, beautiful negative space, coherent lighting from upper left. No white strips, panel dividers, outside border, watermarks, invented logos, extra flowers, animals, clouds of particles or neon effects. Highest visual quality and exquisite material differentiation.
```

# 文件校验

主海报 SHA-256：6cc2ad06551aac05a782377d85e2167896b2035513172ea9ba09cdcc5846c36d

原创底图 SHA-256：2f02439e5e71f1ddfaa89f9618d08ddbd5dd907a5b48fcdd4e1fd28ae0257e83

本作已获所有者许可用于公开案例展示。
