Original synthesized sound-design derivative. No external music or recordings. Public reuse license not selected.

Restore: requires Python 3 + NumPy and FFmpeg. Run `python generate.py --restore .` to mix supplied lossless stems with preserved silent preview into restored-demo.mp4. Run `python generate.py --regenerate rain-study` to regenerate FLAC stems using the fixed recipe and original scene. Source MIDI values are an original short instrumental arrangement, not a named song.

The original visual scene is an illustration, not a real-world measurement. The video shows fixed default parameters; controls remain in the online interactive original. Audio is illustrative; no voice. Soundtrack ends with a fade and is not a seamless audiovisual loop.

Rain-study alone replaces the legacy NO AUDIO footer in its derivative, without changing original source or preview. DejaVuSansMono system font is required for this label; font is not bundled.

Technical checks are distinct from subjective listening, continuous viewing and browser/mobile player verification, which remain unverified.
