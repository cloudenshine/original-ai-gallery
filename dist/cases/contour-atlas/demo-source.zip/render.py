from pathlib import Path
import json,subprocess,wave
import numpy as np
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).parent
spec=json.loads((root/'cues.json').read_text());SR=48000;N=SR*spec['duration'];t=np.arange(N)/SR
bgm=np.zeros(N);sfx=np.zeros(N)
# Three deliberately related six-second musical phrases: Dm9, Bbmaj7, resolved Dm.
chords=[[146.832,174.614,220,261.626,329.628],[116.541,146.832,174.614,220],[146.832,174.614,220,293.665]]
for k,chord in enumerate(chords):
 a=k*6*SR;b=(k+1)*6*SR;u=np.arange(b-a)/SR
 env=np.minimum(u/.7,1)*np.minimum((6-u)/.9,1)
 for f in chord:bgm[a:b]+=.035*env*(np.sin(2*np.pi*f*u)+.18*np.sin(2*np.pi*f*2*u))
 # Slow plucked phrase leaves space at each selection.
 for j in range(1,6):
  start=a+j*SR;v=np.arange(min(2*SR,N-start))/SR;f=chord[(j+k)%len(chord)]*2
  bgm[start:start+len(v)]+=.06*np.exp(-v*3)*np.sin(2*np.pi*f*v)*(1-np.exp(-v*100))
for event in spec['selectionEvents']:
 start=int(event*SR);v=np.arange(int(.24*SR))/SR
 sfx[start:start+len(v)]=.16*np.sin(2*np.pi*(880*v+420*v*v))*np.exp(-v*23)*np.minimum(v/.004,1)
fade=np.minimum(t/.15,1)*np.minimum((spec['duration']-t)/.4,1)
for name,data in [('bgm',bgm*fade),('sfx',sfx),('mix',(bgm*fade+sfx)*.9)]:
 pcm=np.clip(data,-1,1); stereo=np.column_stack([pcm,pcm]);raw=(stereo*32767).astype('<i2').tobytes()
 p=subprocess.run(['ffmpeg','-v','error','-y','-f','s16le','-ar',str(SR),'-ac','2','-i','pipe:0',str(root/(name+'.flac'))],input=raw,check=True)
 print(name,'peak',float(np.abs(pcm).max()),'rms',float(np.sqrt(np.mean(pcm**2))))
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
f=ImageFont.truetype(font,24);small=ImageFont.truetype(font,18)
states=[Image.open(root/f'states/seed-{s}.png').convert('RGB') for s in range(3)]
cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1200x900','-r','30','-i','pipe:0','-i',str(root/'mix.flac'),'-c:v','libx264','-crf','19','-preset','fast','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart',str(root/'demo.mp4')]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for frame in range(spec['duration']*spec['fps']):
 sec=frame/spec['fps'];cue=next(c for c in reversed(spec['seeds']) if sec>=c['time']);s=cue['seed'];im=Image.new('RGB',(1200,900),'#102628');im.paste(states[s],(0,0));d=ImageDraw.Draw(im)
 d.line((0,800,1200,800),fill='#78958c',width=2)
 d.text((36,816),'种子切换导览 · 离线合成',font=f,fill='#ecddac')
 d.text((36,856),'操作示意：同一规则，三个离散状态；并非实测地图。',font=small,fill='#b2c3ba')
 pulse=any(0<=sec-event<.4 for event in spec['selectionEvents'])
 d.rounded_rectangle((868,819,1163,881),radius=12,fill='#ed784e' if pulse else '#294748',outline='#78958c',width=2)
 d.text((890,833),f'种子 {s:02}  /  换一座岛',font=f,fill='#102628' if pulse else '#ecddac')
 p.stdin.write(im.tobytes())
p.stdin.close();assert p.wait()==0
