import {contourSVG,contourPoints} from './geometry.mjs';
import {createRequire} from 'node:module'; const sharp=createRequire(import.meta.url)('sharp');
import fs from 'node:fs';
fs.mkdirSync('states',{recursive:true});
for(let s=0;s<3;s++){
 const svg=contourSVG(s); if(svg!==contourSVG(s))throw Error('determinism');
 if((svg.match(/<path /g)||[]).length!==31)throw Error('path count');
 for(let l=0;l<31;l++){const p=contourPoints(l,s);if(p.length!==161||JSON.stringify(p[0])!==JSON.stringify(p[160])||!p.flat().every(Number.isFinite))throw Error('geometry');}
 fs.writeFileSync(`states/seed-${s}.svg`,svg);await sharp(Buffer.from(svg)).png().toFile(`states/seed-${s}.png`);
}
if(contourSVG(0)===contourSVG(1)||contourSVG(1)===contourSVG(2))throw Error('seed differences');
console.log('93 closed finite curves; deterministic distinct seed states PASS');
