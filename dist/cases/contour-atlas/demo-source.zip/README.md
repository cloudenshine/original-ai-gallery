# 无名地形：种子切换导览
18 秒、1200×900、30fps 离线合成，展示原始 contourSVG 的种子 00、01、02，每个停留 6 秒。曲线不插值，不模拟地形生长，不是实测地理数据或浏览器录屏。底部选择框是导览标注，并非可点击控件。原网页交互保留在 index.html，配套 case.css 一并保存（原页面引用 ../case.css，恢复时将它放在上一级）。

制作：Node.js + sharp 运行 `node export-states.mjs`；Python 3 + numpy + Pillow、FFmpeg 运行 `python3 render.py`。Linux 中文字体使用 Noto Sans CJK Regular；本包不分发字体，其他平台可将 render.py 的字体路径指向已授权中文字体。

bgm.flac、sfx.flac、mix.flac 是 48kHz 双声道无损音源；配乐与选择提示音由 render.py 原创合成，无外部采样、无旁白。cues.json 同时驱动切换与音效时点。

完整源文件与音轨哈希见 SOURCE-MANIFEST.json。原源码与新增媒体公开复用许可尚未选定。媒体技术核验不代表完整实时观看或主观听审。
