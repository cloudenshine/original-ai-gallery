export const escapeXML=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&apos;');
export class Element {
 constructor(tag){if(!/^[a-zA-Z][\w:-]*$/.test(tag))throw Error('Invalid tag');this.tagName=tag;this.attributes={};this.childNodes=[];this.style={};}
 setAttribute(k,v){if(!/^[a-zA-Z][\w:-]*$/.test(k))throw Error('Invalid attr');this.attributes[k]=String(v);}
 appendChild(n){if(n.parentNode)n.parentNode.removeChild(n);this.childNodes.push(n);n.parentNode=this;return n;}
 removeChild(n){let i=this.childNodes.indexOf(n);if(i<0)throw Error('Missing child');this.childNodes.splice(i,1);n.parentNode=null;return n;}
 serialize(){return `<${this.tagName}${Object.entries(this.attributes).map(([k,v])=>` ${k}="${escapeXML(v)}"`).join('')}>${this.childNodes.map(n=>n.serialize()).join('')}</${this.tagName}>`;}
}
export const document={createElementNS:(_,tag)=>new Element(tag)};
