import fs from 'node:fs';
import {createRequire} from 'node:module';
import {document} from './svg-dom.mjs';
import * as THREE from './vendor/three.module.min.js';
import {SVGRenderer} from './vendor/SVGRenderer.js';
import {sampleField,ringRadius,viewDistance} from './model.mjs';
const require=createRequire(import.meta.url);
const sharp=require(process.env.SHARP_PATH||'/workspace/scratch/91b243ead0f0/opencontent-taskboard/node_modules/sharp');
globalThis.document=document;
const W=1280,H=720,svgMode=true;
let renderer=new SVGRenderer();renderer.setPrecision(2);renderer.setQuality('high');renderer.setClearColor(new THREE.Color('#121e27'));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setSize(920,560);
let scene,camera,mesh,wire,probeMarker,probeStem,sources=[],rings=[];
 scene=new THREE.Scene();scene.fog=new THREE.Fog('#121e27',16,30);camera=new THREE.PerspectiveCamera(40,1,.1,60);scene.add(svgMode?new THREE.AmbientLight('#c3d9dc',.5):new THREE.HemisphereLight('#edf5e7','#152933',2.1));const key=new THREE.DirectionalLight('#fff0d3',svgMode?.85:2.6);key.position.set(-3,7,5);scene.add(key);const rim=new THREE.DirectionalLight('#779ca8',svgMode?.35:1.5);rim.position.set(5,3,-5);scene.add(rim);
 const geometry=new THREE.BufferGeometry(),positions=[],colors=[],indices=[];const nx=svgMode?48:120,nz=svgMode?36:90;
 for(let j=0;j<=nz;j++)for(let i=0;i<=nx;i++){positions.push(-4+i*8/nx,0,-3+j*6/nz);colors.push(1,1,1);}
 for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){const a=j*(nx+1)+i,b=a+1,c=a+nx+1,d=c+1;indices.push(a,c,b,b,c,d);}
 geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geometry.setIndex(indices);
 mesh=new THREE.Mesh(geometry,new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide}));scene.add(mesh);
 wire=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:'#adc5b0',wireframe:true,transparent:true,opacity:.085,depthWrite:false}));wire.position.y=.007;if(!svgMode)scene.add(wire);
 const base=new THREE.Mesh(new THREE.BoxGeometry(8.09,.12,6.09),new THREE.MeshLambertMaterial({color:'#1b333c'}));base.position.y=-.03;if(!svgMode)scene.add(base);
 const grid=new THREE.GridHelper(10,20,'#51645f','#263b40');grid.position.y=-.095;if(!svgMode)scene.add(grid);
 for(let i=0;i<2;i++){
 const group=new THREE.Group();const sphere=new THREE.Mesh(new THREE.SphereGeometry(.095,svgMode?12:24,svgMode?8:16),new THREE.MeshLambertMaterial({color:'#f3b77c',emissive:'#ba5c28',emissiveIntensity:.55}));sphere.position.y=1.48;group.add(sphere);
 const stem=new THREE.Mesh(new THREE.CylinderGeometry(.01,.01,1.46,8),new THREE.MeshBasicMaterial({color:'#d29c6c',transparent:true,opacity:.7}));stem.position.y=.75;group.add(stem);
 const collar=new THREE.Mesh(new THREE.TorusGeometry(.17,.006,6,56),new THREE.MeshBasicMaterial({color:'#edc49d'}));collar.rotation.x=Math.PI/2;collar.position.y=1.48;group.add(collar);scene.add(group);sources.push(group);
 for(let j=0;j<9;j++){const ring=svgMode?new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(Array.from({length:72},(_,n)=>new THREE.Vector3(Math.cos(n/72*Math.PI*2),Math.sin(n/72*Math.PI*2),0))),new THREE.LineBasicMaterial({color:i?'#e7b982':'#9cbdba',transparent:true,opacity:.13})):new THREE.Mesh(new THREE.TorusGeometry(1,.003,3,150),new THREE.MeshBasicMaterial({color:i?'#e7b982':'#9cbdba',transparent:true,opacity:.13,depthWrite:false}));ring.rotation.x=Math.PI/2;ring.position.y=1.24;ring.userData={source:i,index:j};scene.add(ring);rings.push(ring);}
 }
 probeMarker=new THREE.Mesh(new THREE.OctahedronGeometry(.095),new THREE.MeshBasicMaterial({color:'#f7f3d1'}));scene.add(probeMarker);probeStem=new THREE.Mesh(new THREE.CylinderGeometry(.006,.006,1.7,6),new THREE.MeshBasicMaterial({color:'#f7f3d1',transparent:true,opacity:.65}));scene.add(probeStem);

camera.aspect=920/560;camera.updateProjectionMatrix();const distance=viewDistance(camera.aspect);camera.position.set(distance*Math.cos(.84)*Math.sin(.65),distance*Math.sin(.84),distance*Math.cos(.84)*Math.cos(.65));camera.lookAt(0,.32,0);
function frame(t){
 const preset=t<8?'coherent':t<16?'opposed':'short';
 const params={frequency:preset==='short'?440:220,separation:2.4,phase:preset==='opposed'?180:0};
 const pos=mesh.geometry.attributes.position,col=mesh.geometry.attributes.color;
 const cool=new THREE.Color('#22424f'),mid=new THREE.Color('#67978e'),warm=new THREE.Color('#ecd4a0');
 for(let i=0;i<pos.count;i++){const q=sampleField(pos.getX(i),pos.getZ(i),params),h=q.intensity;pos.setY(i,.06+1.08*h);const color=h<.5?cool.clone().lerp(mid,h*2):mid.clone().lerp(warm,(h-.5)*2);col.setXYZ(i,color.r,color.g,color.b);}
 pos.needsUpdate=true;col.needsUpdate=true;mesh.geometry.computeVertexNormals();sources.forEach((s,i)=>s.position.x=(i?1:-1)*1.2);
 probeMarker.position.set(0,1.72,1.8);probeStem.position.set(0,.87,1.8);
 rings.forEach(r=>{r.position.x=(r.userData.source?1:-1)*1.2;const radius=ringRadius(t,r.userData.index,r.userData.source,params);r.visible=radius<4.7;r.scale.setScalar(radius);r.material.opacity=.12*(1-radius/5);});
 renderer.render(scene,camera);
 const q=sampleField(0,1.8,params),titles={coherent:'同相 · 中央相长',opposed:'反相 · 中央相消',short:'短波 · 条纹更密'};
 const text=(x,y,size,s,color='#e9e5d4')=>`<text x="${x}" y="${y}" font-size="${size}" fill="${color}" font-family="Noto Sans CJK SC,sans-serif">${s}</text>`;
 let svg=renderer.domElement.serialize().replace('<svg ','<svg x="0" y="116" ');
 return `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720"><rect width="1280" height="720" fill="#121e27"/>${svg}${text(42,53,30,'让安静有形')}${text(42,84,16,'原模型离线演示 · Three.js 官方 SVG 3D · 非 WebGL 录屏','#9cbdba')}${text(920,190,23,titles[preset])}${text(920,238,19,params.frequency+' Hz / '+params.phase+'°')}${text(920,278,17,'探针 (0.0, 1.8) m')}${text(920,345,48,(q.intensity*100).toFixed(0)+'%')}${text(920,380,17,'局部归一化声强 Irel')}${text(920,428,17,'波长 '+q.wavelength.toFixed(2)+' m')}${text(920,480,15,'暖色峰：相长')}${text(920,510,15,'冷色谷：相消')}${text(42,653,18,t>=24?'相位改变中央强度；频率改变条纹间距。':preset==='opposed'?'同一探针、等距两源，反相使中央强度趋近零。':preset==='short'?'频率加倍，波长减半；中央仍然相长。':'保持探针位置，接下来只改变两源相位。')}${text(42,687,13,'理想自由空间 · 局部归一化时间平均值，非校准声压级 / 空气位移 · 环纹为慢速示意 · 声音非实录','#9cbdba')}</svg>`;
}
fs.mkdirSync('../frames',{recursive:true});fs.mkdirSync('../qa',{recursive:true});
if(process.argv.includes('--test-frame')){let s=frame(10);fs.writeFileSync('../qa/test.svg',s);await sharp(Buffer.from(s)).png().toFile('../qa/test.png');console.log('paths', (s.match(/<path/g)||[]).length);}
else for(let i=0;i<300;i++){await sharp(Buffer.from(frame(i/10))).png().toFile(`../frames/${String(i).padStart(4,'0')}.png`);if(i%30===0)console.log(i);}
