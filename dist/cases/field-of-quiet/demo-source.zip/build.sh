#!/usr/bin/env bash
set -euo pipefail
node render.mjs
python audio.py
ffmpeg -y -v error -framerate 10 -i ../frames/%04d.png -i ../audio/mix.flac -c:v libx264 -crf 19 -pix_fmt yuv420p -c:a aac -b:a 160k -movflags +faststart -shortest ../demo.mp4
