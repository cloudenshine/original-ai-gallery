# Offline faithful SVG 3D demonstration

This folder retains the original interactive app, model, UI and official Three.js r160 vendor files unchanged. Open index.html via an HTTP server to use the original interaction. render.mjs reproduces its actual fallback scene, original 48×36-cell mesh, lights, camera, normalized model, and slowly expanding rings through the bundled official SVGRenderer. svg-dom.mjs is only a narrow SVG node/attribute serializer, not a browser, layout engine, or replacement 3D renderer.

The 30-second demonstration compares coherent 220 Hz, opposed 220 Hz and coherent 440 Hz with a fixed probe at (0,1.8) m and separation 2.4 m. Central Irel is 1, approximately 0, then 1. The short-wave scene demonstrates denser spatial stripes, not lower central intensity. Height and colour represent local normalized time-averaged intensity, not particle displacement, loudness or calibrated SPL. Circular rings are artificially slow propagation guides, not real acoustic transients.

Dependencies already present at production: Node.js, Sharp 0.35.4 (set SHARP_PATH to its installed directory), Python3 with NumPy, FFmpeg, Noto Sans CJK SC. No browser, network, new dependency installation or paid API is involved. To reproduce, from this directory run `node render.mjs`, then `python audio.py`; render outputs go to ../frames and audio to ../audio. Encoding instructions are in build.sh. Source interactive app remains separate from demo playback.

Audio: original simple harmonic score, original preset event cues, and illustrative sine probe amplitude 0.07 sqrt(Irel). Music is absent during the comparison; every stem is zero at 9–15 seconds. This is not recorded acoustics or a room/ear simulation. Lossless FLAC stems and cue timing are preserved; the MP4 uses AAC.

Evidence boundaries: source/math and media decode checks do not prove browser operation, WebGL, full real-time viewing, or subjective listening. New offline export does not inherit historical browser validation claimed in the original README. Publication is on hold; this local export is not uploaded.

Licenses: original application and media have no additional reuse license. Bundled Three.js is MIT; see vendor/LICENSE-THREE.txt. Sharp and fonts are environment dependencies rather than vendored files. The original source README provides mathematical assumptions and library sources.
