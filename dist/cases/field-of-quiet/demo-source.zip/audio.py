"""Original generative score/event cues; illustrative probe, not acoustic recording."""
import json, subprocess
from pathlib import Path
import numpy as np
sr=48000; duration=30; t=np.arange(sr*duration)/sr
bgm=np.zeros(len(t));sfx=bgm.copy();probe=bgm.copy()
def envelope(x,a,b,fade=.15):return np.clip((x-a)/fade,0,1)*np.clip((b-x)/fade,0,1)
# Two related original chord phrases, intro suspended, outro resolved.
for start,end,notes in [(0,3,[146.832,220,329.628]),(24,27,[146.832,196,293.665]),(27,30,[164.814,220,329.628])]:
 for j,f in enumerate(notes):
  bgm+=.018*np.sin(2*np.pi*f*t+j*.3)*envelope(t,start,end,.6)*(1+.12*np.sin(2*np.pi*.4*t))
for start in [8,16]:
 u=np.maximum(t-start,0);mask=(t>=start)&(t<start+.18)
 sfx+=.035*np.sin(2*np.pi*(650*u-650*u*u))*np.exp(-u*25)*mask*np.minimum(u/.008,1)
for a,b,f in [(3,8,220),(16,23,440)]: probe+=.07*np.sin(2*np.pi*f*t)*envelope(t,a,b,.05)
Path('../audio').mkdir(exist_ok=True)
def save(name,x):
 pcm=np.rint(np.clip(x,-1,1)*8388607).astype('<i4')<<8
 subprocess.run(['ffmpeg','-y','-v','error','-f','s32le','-ar',str(sr),'-ac','1','-i','pipe:0','-c:a','flac','-sample_fmt','s32',f'../audio/{name}.flac'],input=pcm.tobytes(),check=True)
for name,x in [('bgm',bgm),('sfx',sfx),('probe',probe),('mix',bgm+sfx+probe)]:save(name,x)
json.dump({'sample_rate':sr,'duration':duration,'bgm_windows':[[0,3],[24,30]],'preset_cues':[{'time':8,'duration':.18},{'time':16,'duration':.18}],'probe_windows':[[3,8,220],[16,23,440]],'silence_window':[9,15],'original_score':True,'not_recorded_acoustics':True,'peak':float(np.max(abs(bgm+sfx+probe)))},open('../audio/cues.json','w'),indent=2)
