Original six-second sound-only derivative. Preserve original film, GIF and image/code source. New score is illustrative original synthesis, not physical lunar sound. Existing rights and component notices remain in original-source.zip; no new reuse license is granted.

Restore with Python3, NumPy, SciPy and FFmpeg: python moon_generate.py --restore .
Regenerate lossless stems: python moon_generate.py --regenerate

Video stream is copied. Original image is AI-generated material animated by Python, not model-native GIF. End fade means soundtrack is not seamless. Full decode and technical signal checks do not replace subjective listening, full continuous viewing or browser/mobile verification, which remain unverified.
