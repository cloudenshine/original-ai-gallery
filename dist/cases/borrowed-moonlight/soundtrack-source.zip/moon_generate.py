"""Original sound-only score for the preserved six-second Borrowed Moonlight film."""
from pathlib import Path
import sys,json,subprocess,hashlib,zipfile,shutil,numpy as np
from scipy.interpolate import PchipInterpolator
from synthesis import Score,SR,hz,envelope

def make():
 s=Score(6,91417)
 def notes(a,b,ns,gain=.023):
  n=round((min(6,b+.12)-a)*SR);t=np.arange(n)/SR
  for k,m in enumerate(ns):
   x=(np.sin(2*np.pi*hz(m)*t)+.15*np.sin(4*np.pi*hz(m)*t)+.07*np.sin(6*np.pi*hz(m)*t))*envelope(n,min(.35,n/SR/3),min(.4,n/SR/3));s.add('bgm',a,x,gain,(k-(len(ns)-1)/2)*.08,'Chord MIDI '+str(ns))
 for a,b,ns in [(0,1.5,[48,55,59,62,64]),(1.5,3,[45,55,60,64]),(3,4.5,[53,57,60,64]),(4.5,5.25,[43,57,60,64]),(5.25,6,[48,55,60,64])]:notes(a,b,ns)
 for a,m in [(.25,67),(1,64),(2.75,62),(4,64),(5.25,60)]:
  n=round(min(1.5,6-a)*SR);t=np.arange(n)/SR;x=(np.sin(2*np.pi*hz(m)*t)+.12*np.sin(6*np.pi*hz(m)*t))*np.exp(-t/1.1)*envelope(n,.03,.2);s.add('bgm',a,x,.047,0,'Melody MIDI '+str(m))
 q=2.04;n=round(.12*SR);t=np.arange(n)/SR;e=np.sin(np.pi*t/.12)**2*np.exp(-3*t/.12);x=(s.band(n,800,2400)*.4+.6*np.sin(2*np.pi*(900*t+(550-900)*t*t/(2*.12))))*e;s.add('sfx',q,x,.01,0,'Single first displayed contact at frame51 /25fps')
 P=PchipInterpolator([0,.07,.20,.34,.42,.50,.57,.64,.72,.83,.94,1],[328,341,400,526,557,518,487,513,444,363,330,328]);a=2.04;b=3.8144;start=round(a*SR);end=round(b*SR);tt=np.arange(start,end)/SR;v=np.abs(P.derivative()(tt/5.96))/5.96
 def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
 env=.012*v/(v+100)*smooth((tt-a)/.06)*smooth((b-tt)/.08);x=s.band(len(tt),350,1800)*env;s.add('sfx',a,x,1,0,'Continuous shared-support velocity; exact PCHIP phase s/5.96, ending3.8144')
 return s

def mux(p,outname='demo.mp4'):
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'original-film.mp4'),'-i',str(p/'bgm.flac'),'-i',str(p/'sfx.flac'),'-filter_complex','[1:a][2:a]amix=inputs=2:duration=longest:normalize=0[a]','-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart',str(p/outname)],check=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
 if '--restore' in sys.argv:mux(Path(sys.argv[-1]).resolve(),'restored-demo.mp4')
 elif '--regenerate' in sys.argv:make().save(Path.cwd())
 else:
  root=Path(__file__).resolve().parents[1];src=root.parent/'gallery-next/dist/cases/borrowed-moonlight';out=root/'payload/borrowed-moonlight';out.mkdir(parents=True,exist_ok=True);source=root/'sources/borrowed-moonlight';source.mkdir(parents=True,exist_ok=True)
  s=make();metrics=s.save(out);shutil.copy2(src/'film.mp4',out/'original-film.mp4');mux(out);subprocess.run(['ffmpeg','-v','error','-i',str(out/'demo.mp4'),'-f','null','-'],check=True)
  for n in ['bgm.flac','sfx.flac','original-film.mp4']:shutil.copy2(out/n,source/n)
  shutil.copy2(src/'source.zip',source/'original-source.zip');shutil.copy2(Path(__file__),source/'moon_generate.py');shutil.copy2(Path(__file__).with_name('synthesis.py'),source/'synthesis.py')
  ev={'id':'borrowed-moonlight','sourcePhase':'frame_index/149, frame timestamp=frame_index/25','sourceZipSha256':sha(src/'source.zip'),'originalVideoSha256':sha(src/'film.mp4'),'events':s.events,'metrics':metrics};(source/'event-score.json').write_text(json.dumps(ev,indent=2));(source/'README.md').write_text('Original six-second sound-only derivative. Preserve original film, GIF and image/code source. New score is illustrative original synthesis, not physical lunar sound. Existing rights and component notices remain in original-source.zip; no new reuse license is granted.\n\nRestore with Python3, NumPy, SciPy and FFmpeg: python moon_generate.py --restore .\nRegenerate lossless stems: python moon_generate.py --regenerate\n\nVideo stream is copied. Original image is AI-generated material animated by Python, not model-native GIF. End fade means soundtrack is not seamless. Full decode and technical signal checks do not replace subjective listening, full continuous viewing or browser/mobile verification, which remain unverified.\n')
  manifest={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.iterdir() if p.name!='SOURCE-MANIFEST.json'};(source/'SOURCE-MANIFEST.json').write_text(json.dumps(manifest,indent=2))
  with zipfile.ZipFile(out/'soundtrack-source.zip','w',zipfile.ZIP_DEFLATED,6) as z:
   for p in sorted(source.iterdir()):z.write(p,p.name)
  assert (out/'soundtrack-source.zip').stat().st_size<10_000_000
  public={'id':'borrowed-moonlight','artifact':'demo.mp4','originalSilentVideo':'film.mp4','originalGif':'animation.gif','sources':'soundtrack-source.zip','videoSha256':sha(out/'demo.mp4'),'sourceVideoSha256':sha(src/'film.mp4'),'soundtrack':'Original six-second harmonic phrase with one source-aligned water contact and continuous PCHIP support texture. No narration or recordings.','visualChange':'Original video stream copied unchanged.','rights':'Original-source notices retained; no new public reuse license.','verification':{'fullDecode':True,'frameSamplesInspected':False,'subjectiveListening':False,'continuousRealtimeViewing':False,'browserMobilePlayback':False,'audioMetrics':metrics},'container':{'duration':6,'width':768,'height':768,'fps':25,'audio':'AAC stereo 32000 Hz'}};(out/'demo-provenance.json').write_text(json.dumps(public,indent=2,ensure_ascii=False))
  (out/'demo.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>借一弯月光 · 有声演示</title><style>body{background:#111d21;color:#eee;font:16px/1.7 system-ui;margin:0}main{max-width:850px;margin:auto;padding:24px}video{display:block;width:100%;max-height:78vh}a{color:#dce2bb}nav{display:flex;flex-wrap:wrap;gap:18px}</style><main><a href="../../index.html">← 造物案例馆</a><h1>借一弯月光 · 有声演示</h1><p>保留原六秒画面，加入原创器乐短句与水面接触音效。声音为诗意设计，不代表真实月体或物理声学模拟。</p><video controls playsinline preload="metadata" poster="poster.png"><source src="demo.mp4" type="video/mp4"></video><nav><a href="demo.mp4" download>下载视频</a><a href="index.html">原作品与GIF</a><a href="film.mp4">原静音视频</a><a href="soundtrack-source.zip">声音分轨与源文件</a><a href="demo-provenance.json">来源与验证</a></nav><p>音乐淡出收束，不是无缝声画循环。已全文件解码；输出画面取样待核对，完整连续观看、主观听音及浏览器／手机播放尚未验证。</p></main>')
  print(json.dumps({'metrics':metrics,'zipBytes':(out/'soundtrack-source.zip').stat().st_size}))
