"""Original deterministic motion for 借一弯月光.

This is NOT native GPT-Image-2.6 GIF output. source-art.png is the single
still returned by the built-in image tool. Python supplies all animation.
"""
from pathlib import Path
import json, hashlib, argparse
import numpy as np
from PIL import Image, ImageFilter
from scipy.interpolate import PchipInterpolator
from scipy.ndimage import map_coordinates

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)
W = H = 768
N = 150
DT = 40
SRC = Image.open(ROOT/'source-art.png').convert('RGB').resize((W,H),Image.Resampling.LANCZOS)
A = np.asarray(SRC).astype(np.float32)
Y,X = np.mgrid[:H,:W].astype(np.float32)
CX = 384.
HORIZON = 545.
CUT = 309
CAP_BASE = 328.

# The cap is an actual piece of the generated pearl disk, not a replacement.
lum=A.mean(axis=2)
cap_alpha=np.clip((lum-18)/35,0,1)*(Y>=CUT)*(Y<=350)*(X>285)*(X<485)
cap_alpha[(Y==CUT)] *= .9
cap_rgba=np.dstack([A,cap_alpha*255]).astype(np.uint8)
CAP=Image.fromarray(cap_rgba,'RGBA').crop((280,CUT,490,352))
sky=np.empty_like(A)
# Sample the same image's unoccupied adjacent sky, retaining its vertical grade.
for yy in range(H):
    sy=min(yy,540)
    c=(A[sy,220:240].mean(0)+A[sy,530:550].mean(0))*.5
    sky[yy]=c
# Remove the entire original lower-rim glow as well as its bright material.
# Otherwise a ghost crescent remains at the origin after the physical piece leaves.
erase=(Y>=CUT)*np.clip((371-Y)/14,0,1)*np.clip((X-268)/22,0,1)*np.clip((502-X)/22,0,1)
BASE=A*(1-erase[:,:,None])+sky*erase[:,:,None]

# The approved microstory, mapped to a six-second curve. PCHIP prevents overshoot.
K=np.array([0,.07,.20,.34,.42,.50,.57,.64,.72,.83,.94,1.])
POS=np.array([328,341,400,526,557,518,487,513,444,363,330,328.])
POSITION=PchipInterpolator(K,POS)
# Contact is exact: water height and fragment position use the same event clock.
WK=np.array([0,.30,.34,.42,.50,.57,.64,.685,.72,.83,.94,1.])
WV=np.array([0,0,1.5,-29.5,9.5,40.5,14.5,24,15,1,0,0.])
WAVE=PchipInterpolator(WK,WV)

def render(t):
    if t<=0 or t>=1:
        return SRC.copy()
    pos=float(POSITION(t))
    wave=float(WAVE(t))
    # Enforce the same contact relation throughout depression and supporting crest.
    if .34<=t<=.64:
        wave=HORIZON-(pos+17.5)
    base=BASE.copy()
    if abs(wave)>.001:
        spread=76.+22.*max(0,(t-.64)/.19)
        g=np.exp(-((X-CX)/spread)**2)
        water_top=HORIZON-wave*g
        depth=np.maximum(Y-water_top,0)
        falloff=np.maximum(1-depth/200.,0)**2
        shift=wave*g*falloff
        source_y=np.clip(Y+shift,0,H-1)
        # A local, event-driven horizontal compression gives the water body depth.
        source_x=np.clip(X+(X-CX)*g*wave*.002*falloff,0,W-1)
        warped=np.stack([map_coordinates(A[:,:,c],[source_y,source_x],order=1,mode='nearest') for c in range(3)],2)
        # Camera and distant sea stay fixed; only the contact neighborhood deforms.
        zone=(Y>HORIZON-70)&(Y<HORIZON+200)
        mask=np.clip(Y-water_top+.5,0,1)
        water=sky*(1-mask[:,:,None])+warped*mask[:,:,None]
        # Broad specular edge tracks the same surface; no independent particles.
        edge=np.exp(-((Y-water_top-1.5)/2.4)**2)*g*min(abs(wave)/30,1)
        water += edge[:,:,None]*np.array([42.,38.,24.])
        base=np.where(zone[:,:,None],water,base)
    canvas=Image.fromarray(np.clip(base,0,255).astype(np.uint8),'RGB').convert('RGBA')
    dy=pos-CAP_BASE
    # Subpixel translation preserves nacre identity across the whole loop.
    translated=CAP.transform(CAP.size,Image.Transform.AFFINE,(1,0,0,0,1,-(dy-int(dy))),Image.Resampling.BICUBIC)
    canvas.alpha_composite(translated,(280,CUT+int(dy)))
    return canvas.convert('RGB')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--preview',action='store_true'); args=ap.parse_args()
    if args.preview:
        ts=[0,.20,.34,.42,.57,.64,.72,.83,1]
        sheet=Image.new('RGB',(3*384,3*384),(0,0,0))
        for i,t in enumerate(ts):
            f=render(t); f.save(OUT/f'preview-{i}.png')
            sheet.paste(f.resize((384,384)),((i%3)*384,(i//3)*384))
        sheet.save(OUT/'contact-sheet.png');return
    frames=[]
    frame_dir=ROOT/'frames';frame_dir.mkdir(exist_ok=True)
    for i,t in enumerate(np.linspace(0,1,N)):
        f=render(float(t)); f.save(frame_dir/f'{i:04d}.png');frames.append(f)
    palette_source=Image.new('RGB',(W*5,H*3))
    for i,j in enumerate(np.linspace(0,N-1,15).astype(int)):
        palette_source.paste(frames[j],((i%5)*W,(i//5)*H))
    pal=palette_source.quantize(colors=256,method=Image.Quantize.MEDIANCUT)
    indexed=[f.quantize(palette=pal,dither=Image.Dither.FLOYDSTEINBERG) for f in frames]
    gif=OUT/'借一弯月光-真实循环.gif'
    indexed[0].save(gif,save_all=True,append_images=indexed[1:],duration=DT,loop=0,optimize=False,disposal=1)
    im=Image.open(gif); decoded=[];durations=[]
    for i in range(im.n_frames):
        im.seek(i);decoded.append(np.asarray(im.convert('RGB')).copy());durations.append(im.info.get('duration'))
    hashes=[hashlib.sha256(x.tobytes()).hexdigest() for x in decoded]
    diffs=[float(np.abs(decoded[i].astype(float)-decoded[i-1]).mean()) for i in range(1,len(decoded))]
    seam=float(np.abs(decoded[-1].astype(float)-decoded[0]).mean())
    proof={'format':im.format,'size':im.size,'rendered_frames':N,'encoded_frames':im.n_frames,'unique_decoded_frames':len(set(hashes)),'duration_ms':sum(durations),'durations_ms':durations,'loop':im.info.get('loop'),'first_last_mean_absolute_difference':seam,'max_adjacent_mean_absolute_difference':max(diffs),'mean_adjacent_mean_absolute_difference':float(np.mean(diffs)),'source_model_identifier':'not exposed by built-in tool','animation_method':'Python code: source cutout, PCHIP motion, localized event-driven water deformation, fixed GIF palette','native_image26_gif':False,'sha256':hashlib.sha256(gif.read_bytes()).hexdigest()}
    (ROOT/'verification.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False))
    print(json.dumps({k:v for k,v in proof.items() if k!='durations_ms'},indent=2,ensure_ascii=False))

if __name__=='__main__':main()
