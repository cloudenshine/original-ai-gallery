# 参考与差异说明

本轮于 2026-11-07 阅读了以下网页及本地已交付案例。网页为当时读取快照，不表示完整复现、完整看片或对每项模型标签独立验证。未将第三方图像、音乐、代码或提示词作为生成输入。

- [Evolink 参考目录](https://github.com/Evolink-AI/awesome-gpt-image-2-6-prompts-and-api)：借鉴案例对应真实输出、提示词及模型归属边界的呈现方式。
- [其中的新版本案例页](https://github.com/Evolink-AI/awesome-gpt-image-2-6-prompts-and-api/blob/codex/gpt-image-2-5-prompts/cases/gpt-image-2-6.md)：定点阅读了画廊海报案例的输入限制及文字提示。没有取其画框、冬景、版式或构图；本图无参考图、无画框、无版面文字。
- [Awesome AI Motion](https://github.com/guanmo-ai/awesome-ai-motion)：核对了叙事、短动效与交互的不同分类，以及来源/核验范围须分开表述。本轮只制作静态图，不添加技术循环冒充影片。
- [Lemo-Opuscar](https://github.com/lemomo-ai/lemo-opuscar) 与 [DIRECTOR.md](https://github.com/lemomo-ai/lemo-opuscar/blob/main/DIRECTOR.md)：取其由材料行为承载变化、剔除多余符号的原则，没有复制角色、镜头、配乐或风格示例。


独创性限定：这次具体场景、构图约束与提示词为新写，未挪用已有图片或提示词。拆旧毛线重织与大小手套并非新题材；未做全世界图像检索，也不宣称从未有人做过。
