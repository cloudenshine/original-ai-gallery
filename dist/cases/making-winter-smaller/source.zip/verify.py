#!/usr/bin/env python3
"""Verify delivered stills as files. Does not score art or validate knitting."""
from pathlib import Path
from PIL import Image
import hashlib, json, struct, zlib

ROOT = Path(__file__).resolve().parent

def png_chunks(data):
    assert data[:8] == b'\x89PNG\r\n\x1a\n', 'PNG signature'
    p, chunks = 8, []
    while p < len(data):
        n = struct.unpack('>I', data[p:p+4])[0]
        kind = data[p+4:p+8]
        payload = data[p+8:p+8+n]
        expected = struct.unpack('>I', data[p+8+n:p+12+n])[0]
        assert zlib.crc32(kind + payload) & 0xffffffff == expected, f'CRC {kind!r}'
        chunks.append(kind.decode('ascii'))
        p += n + 12
        if kind == b'IEND':
            assert p == len(data), 'Trailing data after IEND'
            break
    assert chunks[0] == 'IHDR' and chunks[-1] == 'IEND'
    return chunks

def main():
    records = []
    for p in sorted((ROOT/'artwork').glob('*.png')):
        data = p.read_bytes()
        chunks = png_chunks(data)
        with Image.open(p) as im:
            im.load()
            assert im.size == (1536, 1024), 'Expected image dimensions'
            assert im.format == 'PNG'
            records.append({'path': str(p.relative_to(ROOT)), 'bytes': len(data),
                'sha256': hashlib.sha256(data).hexdigest(), 'width': im.width,
                'height': im.height, 'format': im.format, 'mode': im.mode,
                'png_chunks': chunks, 'full_pixel_decode': 'pass'})
    assert len(records) == 2
    assert records[0]['sha256'] != records[1]['sha256'], 'Revision must differ'
    result = {'status':'pass','scope':'PNG integrity, full pixel decode, dimensions, distinct revisions; not artistic acceptance', 'images':records}
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__': main()
