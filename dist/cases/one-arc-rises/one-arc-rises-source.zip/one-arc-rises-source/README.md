# 一弧升起 / One Arc Rises

一件 AI 协助创作的程序化动力雕塑：同一根黄铜轴带动七枚凸轮，依次托起暖白陶瓷叶片，形成中央高、两端低的弧。20 秒、24 fps，共 480 个场景时点。

## 文件

- `scene/clockwork_bloom_v5.blend`：可直接打开的完整编辑场景。模型、材质、灯光、相机切换及全部 480 时点的关键帧均在文件内。
- `scene/build_scene.py`、`parameters.json`：程序化建模与动画输入；场景保留生成时的原始参数快照。
- `scene/events.json`、`cam_mesh_vertices.npz`：实际可见凸轮网格及逐帧支撑、起升、停稳记录。
- `scene/verify_scene.py`：重开场景后检查几何接触、导向套余量与共同轴角。
- `audio/soundtrack.py`：原创音乐与机械质感音效的合成程序。
- `audio/music.flac`、`foley.flac`、`master.flac`：音乐、音效及合成母带，48 kHz 双声道、20 秒。
- `SOURCE-MANIFEST.json`：包内文件大小与 SHA-256。

没有使用外购模型、图片纹理、采样音乐或私人照片。这里的运动是根据实际凸轮网格最高点计算的几何约束动画，不是接触动力学模拟，也未作制造或工程安全认证。

## 打开与重建

使用 Blender 4.3.2。打开 `.blend` 后即可浏览模型与完整时轴；相机切换由时间线标记保存。

若重建，请先解压到一个新副本。生成器会重新写入同目录的场景、事件和网格文件：

```sh
blender -b --factory-startup -P scene/build_scene.py -- --output rebuild
```

音频重建使用 Python、NumPy、SciPy 和 FFmpeg。选择一个新的输出目录，避免覆盖已有分轨：

```sh
python audio/soundtrack.py --events scene/events.json --out regenerated-audio
```

场景采用 AgX、固定曝光和固定照明。交付渲染的 A/B 镜头使用 EEVEE Next、16 samples、1 条阴影射线；D 终镜使用 32 samples、4 条阴影射线，阴影步数为 6。A/B 为帧 1–384，D 为帧 385–480。完整输出与经验证的静止段缓存方式以交付复核清单为准，源场景仍可逐帧重渲。

`parameters.json` 的部分 render/backend 字段是场景生成时保留的早期试渲记录，不代表最终交付范围。文件保留原字节便于追溯；本次最终输出方式以交付复核清单为准。

不同 Blender 版本、设备或颜色管理可能产生不同像素。几何与解码检查不等于连续观看、主观听感审查或用户艺术验收；已完成的检查与未验证项目在交付复核清单中分别记录。GIF、封面和影片是同一作品的不同格式，不计为多个独立案例。

本包不自行声明新的开源或素材再分发许可。
