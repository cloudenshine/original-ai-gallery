"""Reopen-time numerical checks of actual scene geometry and baked animation.

This verifies positions and geometric clearance, not real contact dynamics,
manufacturability, visual readability, or artistic quality.
"""
import argparse,csv,json,sys
from pathlib import Path
import bpy
import numpy as np

ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parent.parent)
a=ap.parse_args(sys.argv[sys.argv.index('--')+1:]);out=a.output.resolve();rows=[];s=bpy.context.scene;vertex_cache={}
def verts(o):
    if o.name not in vertex_cache:vertex_cache[o.name]=np.array([v.co[:]for v in o.data.vertices])
    v=vertex_cache[o.name];m=np.array(o.matrix_world)
    return v@m[:3,:3].T+m[:3,3]
for frame in range(1,481):
    s.frame_set(frame);bpy.context.view_layer.update()
    shaft=bpy.data.objects['COMMON SHAFT - all seven cams fixed']
    for i in range(1,8):
        cam=bpy.data.objects[f'P{i} solid support cam'];v=verts(cam);ix=int(v[:,2].argmax());contact=v[ix]
        shoe=bpy.data.objects[f'P{i} level flat-bottom shoe'];sv=verts(shoe);bottom=sv[:,2].min()
        rod=bpy.data.objects[f'P{i} vertical guide rod'];rv=verts(rod)
        ceramic=bpy.data.objects[f'P{i} ivory glazed ceramic'];cv=verts(ceramic)
        centerx=cam.matrix_world.translation.x
        rows.append({'frame':frame,'time_seconds':(frame-1)/24,'group':f'P{i}','shaft_angle':-shaft.rotation_euler.x,'relative_cam_rotation_max':max(abs(q)for q in cam.rotation_euler),'contact_x':contact[0],'contact_y':contact[1],'contact_z':contact[2],'shoe_bottom_z':bottom,'gap':bottom-contact[2],'shoe_x_margin':.13-abs(contact[0]-centerx),'shoe_y_margin':1.75-abs(contact[1]),'rod_lower_guide_margin':4.01-rv[:,2].min(),'rod_upper_guide_margin':rv[:,2].max()-4.17,'cam_base_clearance':v[:,2].min()-.18,'plate_width':cv[:,0].max()-cv[:,0].min(),'plate_depth':cv[:,1].max()-cv[:,1].min(),'plate_thickness':cv[:,2].max()-cv[:,2].min(),'plate_rotation_max':max(abs(q)for q in ceramic.rotation_euler)})
target=out/'production/actual-mesh-v5-480-frames.csv';target.parent.mkdir(parents=True,exist_ok=True)
with target.open('w')as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'frame_count':480,'group_samples':len(rows),'max_abs_gap':max(abs(r['gap'])for r in rows),'minimum_shoe_x_margin':min(r['shoe_x_margin']for r in rows),'minimum_shoe_y_margin':min(r['shoe_y_margin']for r in rows),'minimum_rod_lower_guide_margin':min(r['rod_lower_guide_margin']for r in rows),'minimum_rod_upper_guide_margin':min(r['rod_upper_guide_margin']for r in rows),'minimum_cam_base_clearance':min(r['cam_base_clearance']for r in rows),'max_relative_cam_rotation':max(r['relative_cam_rotation_max']for r in rows),'max_plate_rotation':max(r['plate_rotation_max']for r in rows),'boundary':'Actual mesh numerical checks only; not dynamic contact simulation or visual acceptance.'}
foot_ranges=[]
for i in range(1,5):
    v=verts(bpy.data.objects[f'Grounded solid foot {i}']);foot_ranges.append([float(v[:,2].min()),float(v[:,2].max())])
base=verts(bpy.data.objects['Thin plinth supported by four real feet'])
summary['feet_z_ranges']=foot_ranges;summary['base_z_range']=[float(base[:,2].min()),float(base[:,2].max())]
summary['ceramic_dimensions']={key:[min(r[key]for r in rows),max(r[key]for r in rows)]for key in ['plate_width','plate_depth','plate_thickness']}
summary['fixed_clearances']={'rear_bracket_top_to_minimum_ceramic_bottom':4.225-(4.09+.07/2),'maximum_shoe_top_to_rear_bracket_bottom':(4.09-.07/2)-3.90,'rear_post_top_overlaps_rail':True}
summary['numeric_pass']=summary['max_abs_gap']<1e-5 and all(summary[k]>0 for k in ['minimum_shoe_x_margin','minimum_shoe_y_margin','minimum_rod_lower_guide_margin','minimum_rod_upper_guide_margin','minimum_cam_base_clearance']) and summary['max_relative_cam_rotation']==0 and all(abs(lo)<1e-6 and abs(hi-.06)<1e-6 for lo,hi in foot_ranges)
(out/'production/actual-mesh-v5-summary.json').write_text(json.dumps(summary,indent=2))
print('VERIFY_COMPLETE',json.dumps(summary),flush=True)
if not summary['numeric_pass']:raise RuntimeError('Actual scene geometry check failed')
