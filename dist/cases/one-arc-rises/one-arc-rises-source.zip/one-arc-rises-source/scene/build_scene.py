"""Rebuild 'One Arc Rises' in Blender 4.3+ using only bundled parameters.

Procedural kinematics, not a manufactured mechanism or contact dynamics solver.
Usage: blender -b --factory-startup -t 9 -P build_scene.py -- --output ../
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import bpy
import bmesh
import numpy as np
from mathutils import Vector

HERE = Path(__file__).resolve().parent
P = json.loads((HERE / 'parameters.json').read_text())
ap = argparse.ArgumentParser()
ap.add_argument('--output', type=Path, default=HERE.parent)
args = ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
OUT = args.output.resolve()
for folder in ('source', 'production', 'renders', 'probes', 'logs'):
    (OUT / folder).mkdir(parents=True, exist_ok=True)

def shaft_motion(t):
    w = .3
    if t <= 1.2:
        return 0., 0.
    if t < 1.4:
        u = t - 1.2
        return w*(u/2-.2/(2*math.pi)*math.sin(math.pi*u/.2)), w/2*(1-math.cos(math.pi*u/.2))
    if t < 16.:
        return w*(t-1.3), w
    if t < 16.7:
        u = t-16.
        return w*14.7+w*(u/2+.7/(2*math.pi)*math.sin(math.pi*u/.7)), w/2*(1+math.cos(math.pi*u/.7))
    return 4.515, 0.

def convex_hull(points):
    pts = sorted(set(map(tuple, points)))
    def cross(o, a, b):
        return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower)>1 and cross(lower[-2],lower[-1],p)<=1e-11:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper)>1 and cross(upper[-2],upper[-1],p)<=1e-11:
            upper.pop()
        upper.append(p)
    return np.array(lower[:-1]+upper[:-1])

def cam_outline(lift, start):
    n=P['motion']['profile_samples']; q=np.arange(n)*2*math.pi/n
    dq=2*math.pi/n; r=.65+lift
    rise_end=shaft_motion(start)[0]+math.acos(.65/r)
    end=4.515+.08
    raw=np.maximum(.65,np.where((q>=rise_end)&(q<=end),r,np.maximum(r*np.cos(q-rise_end),r*np.cos(q-end))))
    # A compact nonnegative angular convolution is a Minkowski average of
    # rotated convex bodies. The follower is never given a separate easing.
    k=np.arange(math.floor(.025/dq)+1)
    weights=np.sin(math.pi*k/(len(k)-1))**2; weights/=weights.sum()
    h=sum(float(v)*np.roll(raw,int(i)) for i,v in zip(k,weights))
    dh=(np.roll(h,-1)-np.roll(h,1))/(2*dq)
    y=-h*np.sin(q)-dh*np.cos(q); z=h*np.cos(q)-dh*np.sin(q)
    return convex_hull(np.c_[y,z])

def mesh_obj(name, verts, faces, material, smooth=False):
    mesh=bpy.data.meshes.new(name+' mesh'); mesh.from_pydata(verts,[],faces); mesh.update()
    bm=bmesh.new(); bm.from_mesh(mesh); bmesh.ops.recalc_face_normals(bm,faces=bm.faces); bm.to_mesh(mesh); bm.free()
    obj=bpy.data.objects.new(name,mesh); bpy.context.collection.objects.link(obj)
    obj.data.materials.append(material)
    for f in obj.data.polygons: f.use_smooth=smooth
    return obj

def bevel(obj,width=.015,segments=3):
    bpy.context.view_layer.objects.active=obj
    mod=obj.modifiers.new('Soft machined edges','BEVEL');mod.width=width;mod.segments=segments
    bpy.ops.object.modifier_apply(modifier=mod.name)
    mod=obj.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL');mod.keep_sharp=True;mod.weight=40
    bpy.ops.object.modifier_apply(modifier=mod.name)

def box(name,loc,scale,mat,bevel_width=.015,parent=None):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    o=bpy.context.object;o.name=name;o.dimensions=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(mat)
    if bevel_width: bevel(o,bevel_width)
    if parent: o.parent=parent
    return o

def cylinder(name,loc,radius,depth,mat,axis='Z',parent=None,vertices=64,edge=.006):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc)
    o=bpy.context.object;o.name=name
    if axis=='X': o.rotation_euler[1]=math.pi/2
    elif axis=='Y': o.rotation_euler[0]=math.pi/2
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(mat)
    for f in o.data.polygons: f.use_smooth=len(f.vertices)==4
    if edge: bevel(o,edge)
    if parent: o.parent=parent
    return o

def ring(name,loc,inner,outer,depth,mat,axis='Z'):
    n=64; vs=[]
    for z,r in ((-depth/2,outer),(depth/2,outer),(-depth/2,inner),(depth/2,inner)):
        for i in range(n):
            a=i*2*math.pi/n;vs.append((r*math.cos(a),r*math.sin(a),z))
    fs=[]
    for i in range(n):
        j=(i+1)%n
        fs.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),(i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
    o=mesh_obj(name,vs,fs,mat,True);o.location=loc
    if axis=='X':o.rotation_euler[1]=math.pi/2
    return o

def srgb(hexstr):
    h=hexstr.lstrip('#');a=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    return tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in a)

def material(name,color,metallic=0.,roughness=.35,coat=0.):
    m=bpy.data.materials.new(name);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*srgb(color),1)
    p.inputs['Metallic'].default_value=metallic;p.inputs['Roughness'].default_value=roughness
    p.inputs['Coat Weight'].default_value=coat;p.inputs['Coat Roughness'].default_value=.19
    p.inputs['IOR'].default_value=1.46
    return m

def ceramic_halfwidth(y):
    # Monotone cubic Hermite spindle body and a true radius .015 rounded tip.
    y=abs(float(y))
    if y>=1.585:return math.sqrt(max(0.,.015**2-(y-1.585)**2))
    xs=[0.,.8,1.3,1.55,1.585];ys=[.34,.2,.075,.018,.015]
    h=[xs[i+1]-xs[i]for i in range(4)];delta=[(ys[i+1]-ys[i])/h[i]for i in range(4)]
    slopes=[0.]
    for i in range(1,4):
        w1=2*h[i]+h[i-1];w2=h[i]+2*h[i-1]
        slopes.append((w1+w2)/(w1/delta[i-1]+w2/delta[i]))
    slopes.append(0.)
    j=next(i for i in range(4)if y<=xs[i+1]);t=(y-xs[j])/h[j]
    return (2*t**3-3*t*t+1)*ys[j]+(t**3-2*t*t+t)*h[j]*slopes[j]+(-2*t**3+3*t*t)*ys[j+1]+(t**3-t*t)*h[j]*slopes[j+1]

def ceramic_mesh(mat,foot):
    # Shared fixed spindle: a single analytic shallow crown, no raised lip.
    outline=[]
    for a in np.linspace(0,2*math.pi,128,endpoint=False):
        y=1.6*math.sin(a);x=math.copysign(ceramic_halfwidth(y),math.cos(a));outline.append((x,y))
    n=len(outline);vs=[(x,y,0.)for x,y in outline];fs=[tuple(reversed(range(n)))]
    # First crown ring is the outer edge. Every radial sequence is monotone.
    for scale in np.linspace(1.,1/12,12):
        for bx,by in outline:
            x,y=bx*scale,by*scale;w=ceramic_halfwidth(y);u=y/1.6;v=x/w if w>1e-9 else 1.
            z=.07+.06*max(0.,1-u*u)*max(0.,1-v*v);vs.append((x,y,z))
    for row in range(12):
        for i in range(n):j=(i+1)%n;fs.append((row*n+i,row*n+j,(row+1)*n+j,(row+1)*n+i))
    vs.append((0,0,.13));center=len(vs)-1
    for i in range(n):fs.append((12*n+i,12*n+(i+1)%n,center))
    o=mesh_obj('P1 ivory glazed ceramic',vs,fs,mat,True)
    o.data.materials.append(foot);o.data.polygons[0].material_index=1;o.data.polygons[0].use_smooth=False
    # Only sharp solid boundary edges are rounded. The crown has no added ring.
    bpy.context.view_layer.objects.active=o
    mod=o.modifiers.new('Fine solid ceramic edge','BEVEL');mod.width=.003;mod.segments=3;mod.limit_method='ANGLE';mod.angle_limit=.65
    bpy.ops.object.modifier_apply(modifier=mod.name)
    return o

def camera(name,params):
    data=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(o)
    o.location=params['position'];o.rotation_euler=(Vector(params['target'])-o.location).to_track_quat('-Z','Y').to_euler()
    data.lens=params['lens_mm'];data.sensor_width=36;data.dof.use_dof=False;data.clip_end=300
    return o

def light(name,loc,target,energy,size,size_y,color=(1,1,1),cast_shadow=True):
    data=bpy.data.lights.new(name,'AREA');data.energy=energy;data.shape='RECTANGLE';data.size=size;data.size_y=size_y;data.color=color;data.use_shadow=cast_shadow
    o=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(o);o.location=loc
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()

bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.name='One Arc Rises - procedural kinematics'
scene.render.engine='BLENDER_EEVEE_NEXT';scene.eevee.taa_render_samples=32
scene.cycles.device='CPU';scene.cycles.samples=24
scene.cycles.use_denoising=False;scene.cycles.use_adaptive_sampling=False;scene.cycles.seed=27
scene.cycles.max_bounces=5;scene.cycles.diffuse_bounces=3;scene.cycles.glossy_bounces=3
scene.cycles.transmission_bounces=0;scene.cycles.volume_bounces=0
scene.cycles.caustics_reflective=False;scene.cycles.caustics_refractive=False
scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.render.resolution_percentage=100
scene.render.fps=24;scene.frame_start=1;scene.frame_end=480
scene.render.threads_mode='FIXED';scene.render.threads=9;scene.render.use_persistent_data=True
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
scene.render.film_transparent=False;scene.render.use_motion_blur=False
scene.view_settings.view_transform='AgX'
try:scene.view_settings.look='AgX - Medium High Contrast'
except TypeError:scene.view_settings.look='Medium High Contrast'
scene.view_settings.exposure=P['backend']['exposure_ev']
scene.world.use_nodes=True;scene.world.node_tree.nodes.get('Background').inputs[0].default_value=(.78,.82,.80,1)
scene.world.node_tree.nodes.get('Background').inputs[1].default_value=P['lights_and_materials']['world_fill']['strength']

ivory=material('Warm ivory ceramic - thin stable glaze','#EEE4D2',0,.28,.12)
unglazed=material('Quiet warm unglazed underside','#D9CBB2',0,.48,0)
brass=material('Satin brass - no wood texture','#A38248',1,.42)
steel=material('Restrained satin rod','#889187',.65,.45)
shoe_mat=material('Matte deep green-grey shoe','#344137',.55,.68)
paint=material('Deep green-grey enamel support','#26382D',.18,.55)
stone=material('Warm limestone-grey photographic ground','#28352D',0,.74)

box('Thin plinth supported by four real feet',(0,0,.12),(7.6,4.2,.12),paint,.032)
for j,(x,y) in enumerate(P['world']['base']['feet']['centers_xy'],1):
    box(f'Grounded solid foot {j}',(x,y,.03),(.4,.4,.06),paint,.012)
cyc_profile=[(-25.,0.),(9.,0.)]
for a in np.linspace(0,math.pi/2,65)[1:]:cyc_profile.append((9+5*math.sin(a),5-5*math.cos(a)))
cyc_profile.append((14.,40.))
cyc_verts=[(x,y,z)for y,z in cyc_profile for x in (-80.,80.)]
cyc_faces=[(2*i,2*i+1,2*i+3,2*i+2)for i in range(len(cyc_profile)-1)]
mesh_obj('True continuous limestone cyclorama',cyc_verts,cyc_faces,stone,True)
for x in (-3.45,3.45):
    box('Rear structural upright',(x,1.58,2.155),(.10,.10,3.95),paint,.018)
    box('Bearing pedestal',(x,0,1.005),(.2,.3,1.65),paint,.032)
    ring('Fixed shaft bearing',(x,0,2),.105,.20,.22,paint,'X')
    ring('Bearing bronze lip',(x-.115,0,2),.104,.158,.027,brass,'X')
box('Rear guide-support rail',(0,1.58,4.09),(7.03,.10,.08),paint,.016)

shaft=bpy.data.objects.new('COMMON SHAFT - all seven cams fixed',None);bpy.context.collection.objects.link(shaft)
shaft.location=(0,0,2);shaft.rotation_mode='XYZ'
cylinder('One continuous brass axle',(0,0,0),.1,7.4,brass,'X',shaft)
for x in (-3.72,3.72):cylinder('Rotating hex drive end',(x,0,0),.16,.12,brass,'X',shaft,6,.012)

cams=[];carriages=[];shoes=[];rods=[];ceramics=[];guides=[];base_support=[];geometry={}
for i,(x,lift,st) in enumerate(zip(P['world']['x_centers'],P['motion']['lifts'],P['motion']['nominal_starts'])):
    profile=cam_outline(lift,st);n=len(profile);verts=[]
    for xx,sc in ((-.09,.990),(-.065,1.),(.065,1.),(.09,.990)):
        verts.extend([(xx,float(y)*sc,float(z)*sc)for y,z in profile])
    faces=[tuple(reversed(range(n))),tuple(3*n+j for j in range(n))]
    for row in range(3):
        for j in range(n):k=(j+1)%n;faces.append((row*n+j,row*n+k,(row+1)*n+k,(row+1)*n+j))
    cam=mesh_obj(f'P{i+1} solid support cam',verts,faces,brass,True)
    cam.data.polygons[0].use_smooth=False;cam.data.polygons[1].use_smooth=False
    cam.location=(x,0,0);cam.parent=shaft;cams.append(cam)
    cylinder(f'P{i+1} shaft-fixed hub',(x,0,0),.19,.25,brass,'X',shaft)
    realverts=np.array([v.co[:]for v in cam.data.vertices],dtype=float)
    initial=float(realverts[:,2].max()+2);base_support.append(initial)
    geometry[f'P{i+1}_vertices']=realverts
    carrier=bpy.data.objects.new(f'P{i+1} mesh-derived follower assembly',None);bpy.context.collection.objects.link(carrier)
    carrier['support_source']=cam.name;carrier['motion_note']='480 positions sampled from the actual rotating cam mesh; not independently designed easing'
    carriages.append(carrier)
    shoe=box(f'P{i+1} level flat-bottom shoe',(x,0,initial+.06),(.28,3.6,.12),shoe_mat,.009,carrier);shoes.append(shoe)
    rod=cylinder(f'P{i+1} vertical guide rod',(x,0,(initial+.12+4.225)/2),.045,4.225-(initial+.12),steel,'Z',carrier,48,.003);rods.append(rod)
    cylinder(f'P{i+1} shoe-to-rod seat',(x,0,initial+.137),.085,.034,brass,'Z',carrier,48,.004)
    if i==0:ceramic=ceramic_mesh(ivory,unglazed)
    else:
        ceramic=bpy.data.objects.new(f'P{i+1} ivory glazed ceramic',ceramics[0].data);bpy.context.collection.objects.link(ceramic)
    ceramic.location=(x,0,4.225);ceramic.parent=carrier;ceramics.append(ceramic)
    box(f'P{i+1} rear guide bracket',(x,.83,4.09),(.08,1.5,.07),paint,.012)
    guide=ring(f'P{i+1} fixed open guide sleeve',(x,0,4.09),.049,.115,.16,brass);guides.append(guide)

camera_objects={key:camera('CAM_'+key,val)for key,val in P['cameras'].items()}
for shot in P['edit']:
    marker=scene.timeline_markers.new(shot['shot']+' '+shot['camera'],frame=shot['frames_half_open'][0]+1);marker.camera=camera_objects[shot['camera']]
scene.camera=camera_objects['A']
for item in P['lights_and_materials']['fixed_lights']:
    light(item['name'],item['position'],item['target'],item['energy_w'],item['size'][0],item['size'][1],item['color'],item['cast_shadow'])

records=[]
for frame in range(1,481):
    t=(frame-1)/24;theta,speed=shaft_motion(t)
    shaft.rotation_euler[0]=-theta;shaft.keyframe_insert(data_path='rotation_euler',index=0,frame=frame)
    row={'frame_index':frame-1,'blender_frame':frame,'time_seconds':t,'shaft_angle_rad':theta,'shaft_speed_rad_s':speed,'groups':{}}
    for i,cam in enumerate(cams):
        v=geometry[f'P{i+1}_vertices'];y=v[:,1]*math.cos(theta)+v[:,2]*math.sin(theta);z=-v[:,1]*math.sin(theta)+v[:,2]*math.cos(theta)+2
        ix=int(np.argmax(z));support=float(z[ix]);lift=support-base_support[i]
        carriages[i].location.z=lift;carriages[i].keyframe_insert(data_path='location',index=2,frame=frame)
        row['groups'][f'P{i+1}']={'support_z':support,'lift_z':lift,'contact_xyz':[float(cam.location.x+v[ix,0]),float(y[ix]),support], 'shoe_bottom_z':support,'guide_overlap':.16,'cam_base_clearance':float(z.min()-.18)}
    records.append(row)
for obj in [shaft]+carriages:
    for fc in obj.animation_data.action.fcurves:
        for key in fc.keyframe_points:key.interpolation='LINEAR'

events=[]
for i in range(7):
    key=f'P{i+1}';lifts=np.array([row['groups'][key]['lift_z']for row in records]);vel=np.gradient(lifts,1/24)
    for row,v in zip(records,vel):row['groups'][key]['lift_speed']=float(v)
    active=np.flatnonzero(lifts>1e-4);high=np.flatnonzero(lifts>=lifts[-1]-1e-5)
    events.append({'group':key,'rise_start_seconds':float(records[int(active[0])]['time_seconds']),'high_dwell_start_seconds':float(records[int(high[0])]['time_seconds']),'final_lift':float(lifts[-1]),'thresholds':{'rise_lift':1e-4,'dwell_remaining_lift':1e-5}})
event_document={'title':'One Arc Rises','identity':P['identity'],'source_version':'v5 actual visible 2048-profile mesh','fps':24,'frame_count':480,'time_formula':'(blender_frame-1)/24','shaft_start_seconds':1.2,'shaft_stop_seconds':16.7,'final_still_seconds':3.3,'derived_events':events,'all_high_dwell_start_seconds':max(e['high_dwell_start_seconds']for e in events),'camera_cuts':P['edit'],'frames':records}
event_bytes=json.dumps(event_document,ensure_ascii=False,indent=2).encode()
(HERE/'events.json').write_bytes(event_bytes)
(OUT/'production/events-v5.json').write_bytes(event_bytes)
scene['events_sha256']=hashlib.sha256(event_bytes).hexdigest()
np.savez_compressed(HERE/'cam_mesh_vertices.npz',**geometry)

scene['description']=P['identity'];scene['animation_source']='Every native-frame follower position is derived from transformed final cam mesh vertices.'
scene['frame_time']='t=(frame-1)/24';scene['no_external_assets']=True
for f in ('build_scene.py','parameters.json'):
    block=bpy.data.texts.new(f);block.write((HERE/f).read_text())
scene.frame_set(1);scene.camera=camera_objects['A']
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/'clockwork_bloom_v5.blend'))
print('BUILD_COMPLETE',json.dumps({'blender':bpy.app.version_string,'object_count':len(scene.objects),'events':events},ensure_ascii=False),flush=True)
