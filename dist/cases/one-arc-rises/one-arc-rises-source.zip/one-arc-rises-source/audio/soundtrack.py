"""Original score and friction sound design, driven by measured cam events.

No samples, network, private voices, or paid services. Requires NumPy, SciPy,
and FFmpeg. Signal checks are not a substitute for subjective listening.
"""
from pathlib import Path
import argparse, hashlib, json, math, re, subprocess
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 48000
DURATION = 20.0
N = int(SR * DURATION)
T = np.arange(N, dtype=np.float64) / SR

def smooth(x):
    x = np.clip(x, 0, 1)
    return x*x*x*(10+x*(-15+6*x))

def window(start, end, attack=.08, release=.2):
    return smooth((T-start)/attack) * smooth((end-T)/release)

def stereo(x, pan=0):
    angle = (pan+1)*np.pi/4
    return x[:,None] * np.array([np.cos(angle), np.sin(angle)])[None,:]

def noise(rng, low, high):
    x=rng.standard_normal(N)
    sos=signal.butter(3,[low,high],btype='bandpass',fs=SR,output='sos')
    x=signal.sosfilt(sos,x)
    return x / np.sqrt(np.mean(x*x))

def pad(freq, start, end, gain, pan, attack=.8, release=1.2):
    u=np.maximum(T-start,0)
    x=(np.sin(2*np.pi*freq*u)+.22*np.sin(2*np.pi*2*freq*u+.17)
       +.07*np.sin(2*np.pi*3*freq*u+.5))
    # Small fixed detuning gives a soft sustained body, not a moving sound cue.
    x=.72*x+.28*np.sin(2*np.pi*(freq*1.0015)*u+.12)
    return stereo(x * window(start,end,attack,release)*gain,pan)

def rounded_note(freq, at, duration, gain, pan):
    u=np.maximum(T-at,0)
    x=(np.sin(2*np.pi*freq*u)+.18*np.sin(2*np.pi*2.006*freq*u)*np.exp(-u*4)
       +.045*np.sin(2*np.pi*3.99*freq*u)*np.exp(-u*7))
    env=(1-np.exp(-u/0.018))*np.exp(-u/max(.2,duration*.38))
    env*=window(at,at+duration,.012,.14)
    return stereo(x*env*gain,pan)

def measure(x):
    proc=subprocess.run(['ffmpeg','-v','info','-f','f32le','-ar',str(SR),
                         '-ac','2','-i','pipe:0','-af',
                         'loudnorm=I=-17:TP=-2:LRA=11:print_format=json',
                         '-f','null','-'],input=x.astype('<f4').tobytes(),
                        stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
    text=proc.stderr.decode('utf-8',errors='replace')
    matches=re.findall(r'\{\s*"input_i".*?\}',text,re.S)
    if not matches:
        raise RuntimeError('FFmpeg did not return the requested loudness measurement')
    return json.loads(matches[-1])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--events',type=Path,required=True)
    ap.add_argument('--out',type=Path,default=Path('audio-output'))
    args=ap.parse_args()
    event_bytes=args.events.read_bytes()
    ev=json.loads(event_bytes)
    assert ev['fps']==24 and ev['frame_count']==480
    frames=ev['frames']; assert len(frames)==480
    ft=np.array([x['time_seconds'] for x in frames])
    assert np.allclose(ft,np.arange(480)/24,atol=1e-10)
    shaft=np.interp(T,ft,[x['shaft_speed_rad_s'] for x in frames])
    shaft=np.maximum(shaft,0)/.3
    start=float(ev['shaft_start_seconds']); stop=float(ev['shaft_stop_seconds'])
    rng=np.random.default_rng(845193)

    music=np.zeros((N,2),np.float64)
    music+=pad(174.614,start=.6,end=stop+1.5,gain=.026,pan=-.12,attack=.85,release=1.6)
    music+=pad(261.626,start=.9,end=stop+.9,gain=.009,pan=.19,attack=1.2,release=1.5)
    music+=pad(440.0,start=9.3,end=stop+.3,gain=.0065,pan=.24,attack=1.5,release=1.4)
    notes=[(2.2,293.665,.85,.034,-.25),(7.65,391.995,1.1,.035,-.12),
           (8.95,440.0,.85,.030,.12),(10.6,329.628,1.15,.030,.2),
           (12.4,523.251,1.5,.024,.30),(14.85,391.995,1.4,.030,-.12),
           (stop+.12,349.228,2.65,.034,0)]
    for at,f,d,g,p in notes:
        music+=rounded_note(f,at,d,g,p)
    # First contact is deliberately quiet enough for the friction layer.
    music*= (1-.58*window(3.0,7.25,.32,.4))[:,None]
    music*= smooth((19.7-T)/.6)[:,None]

    room=np.stack([noise(rng,150,3600),noise(rng,150,3600)],axis=1)*.000045
    mechanism=np.zeros((N,2),np.float64)
    bearing=noise(rng,110,950)*.00115
    bearing+=.00075*np.sin(2*np.pi*182*T)+.00018*np.sin(2*np.pi*364*T)
    mechanism+=stereo(bearing*shaft,0)
    starting=noise(rng,700,2200)*window(start,start+.19,.025,.11)*.0010
    mechanism+=stereo(starting,-.65)
    per_group=[]
    for i in range(7):
        name=f'P{i+1}'
        native=np.array([f['groups'][name]['lift_speed'] for f in frames])
        native[np.abs(native)<1e-5]=0
        assert np.min(native)>-1e-4,'Follower reversal exceeds numerical tolerance'
        vel=np.interp(T,ft,np.maximum(native,0))
        env=np.sqrt(np.clip(vel/.52,0,1))
        rubbing=noise(rng,420+45*i,1750+80*i)*.0032
        rubbing+=noise(rng,1700,3300)*.00018
        mechanism+=stereo(rubbing*env, -.63+.21*i)
        per_group.append({'group':name,'max_measured_lift_speed':float(np.max(native)),
                          'sound_envelope':'sqrt(nonnegative actual mesh lift speed / 0.52)',
                          'pan':round(-.63+.21*i,3)})
    # A very short material decay is allowed after stopping, not a fake motor tail.
    mechanism*=smooth((stop+.065-T)/.065)[:,None]
    foley=room+mechanism
    master=music+foley
    initial=measure(master)
    integrated=float(initial['input_i']); peak=float(initial['input_tp'])
    assert math.isfinite(integrated) and math.isfinite(peak)
    gain=min(10**((-17-integrated)/20),10**((-2.5-peak)/20))
    music*=gain; foley*=gain; master=music+foley
    args.out.mkdir(parents=True,exist_ok=True)
    pcm={}
    for name,x in [('music',music),('foley',foley),('master',master)]:
        assert np.max(np.abs(x))<1
        pcm[name]=np.rint(x*32767).astype('<i2')
        wavfile.write(args.out/f'{name}.wav',SR,pcm[name])
        subprocess.run(['ffmpeg','-v','error','-y','-i',str(args.out/f'{name}.wav'),
                        '-c:a','flac',str(args.out/f'{name}.flac')],check=True)
    result=measure(pcm['master'].astype(np.float64)/32768)
    report={'events_sha256':hashlib.sha256(event_bytes).hexdigest(),
            'sample_rate_hz':SR,'channels':2,'samples_per_channel':N,'duration_seconds':20,
            'original_local_synthesis':True,'external_audio_assets':[],
            'shared_events_source':args.events.name,'shaft_start_seconds':start,'shaft_stop_seconds':stop,
            'music_notes':[{'at':x[0],'frequency_hz':x[1],'duration':x[2]} for x in notes],
            'per_group':per_group,'common_linear_gain':gain,
            'integrated_lufs':float(result['input_i']),'true_peak_db':float(result['input_tp']),
            'loudness_range_lu':float(result['input_lra']),
            'mechanism_abs_max_after_stop_plus_0_07':float(np.max(np.abs(mechanism[T>stop+.07]))),
            'music_abs_max_from_19_7':float(np.max(np.abs(music[T>=19.7]))),
            'stem_sum_max_error_lsb':int(np.max(np.abs(pcm['master'].astype('i4')-pcm['music'].astype('i4')-pcm['foley'].astype('i4')))),
            'subjective_listening':'not_verified',
            'pcm_sha256':{k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in pcm.items()}}
    (args.out/'audio-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
