import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {createCanvas,GlobalFonts}=require('@napi-rs/canvas');
import {springPosition,springCurve} from './model.mjs';
import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
GlobalFonts.registerFromPath(process.env.CJK_FONT||'/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','Noto');
const cvs=createCanvas(1280,720),c=cvs.getContext('2d');
const zetas=[.15,.55,1,1.2],labels=['欠阻尼 · 较多振荡','欠阻尼 · 较快收敛','临界阻尼 · 不越过目标','过阻尼 · 缓慢趋近目标'];
function text(s,x,y,size=22,color='#204a41'){c.fillStyle=color;c.font=`${size}px Noto`;c.fillText(s,x,y)}
function line(x1,y1,x2,y2,col,w=1){c.strokeStyle=col;c.lineWidth=w;c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke()}
const X=t=>110+t/6*1060,Y=p=>560-p*210;
export function draw(t){let part=Math.min(3,Math.floor(t/6)),local=Math.min(6,t-part*6),z=zetas[part];c.fillStyle='#eee9dc';c.fillRect(0,0,1280,720);text('回到平衡，需要几次摆动？',76,65,35);text(`0${part+1} / 04    ${labels[part]}`,78,111,22);text(`ζ = ${z.toFixed(2)}`,1010,108,28);
for(let k=0;k<=6;k++){line(X(k),180,X(k),560,'#d6d8c9');text(String(k),X(k)-6,592,18,'#496452')}
for(let v of [0,.5,1,1.5]){c.setLineDash(v===1?[6,7]:[]);line(110,Y(v),1170,Y(v),v===1?'#7e9484':'#d6d8c9',v===1?2:1);c.setLineDash([]);text(String(v),65,Y(v)+6,18,'#496452')}
line(110,180,110,560,'#7e9484',2);line(110,560,1170,560,'#7e9484',2);text('归一化响应',110,159,18);text('目标 = 1',1070,Y(1)-12,18);text('时间 / s',1090,624,18);
c.beginPath();springCurve(z).forEach(([t,p],i)=>i?c.lineTo(X(t),Y(p)):c.moveTo(X(t),Y(p)));c.strokeStyle='#a8b8aa';c.lineWidth=3;c.stroke();c.beginPath();for(let i=0;i<=local*120;i++){let t=i/120;i?c.lineTo(X(t),Y(springPosition(t,z))):c.moveTo(X(t),Y(springPosition(t,z)))}c.strokeStyle='#204a41';c.lineWidth=4;c.stroke();c.beginPath();c.arc(X(local),Y(springPosition(local,z)),9,0,Math.PI*2);c.fillStyle='#df6e3c';c.fill();c.strokeStyle='#fff6e3';c.lineWidth=3;c.stroke();text(`t = ${local.toFixed(2)} s`,110,624,21);text(`响应 = ${springPosition(local,z).toFixed(3)}`,285,624,21);text('ωn = 5 rad/s · 归一化数学演示，非实测数据',78,677,21);text('意美浮云',1090,677,18);
return cvs;}
const out=process.argv[2]||'frames';fs.mkdirSync(out,{recursive:true});if(process.argv[3]==='--still'){fs.writeFileSync(`${out}/style-frame.png`,draw(.65).toBuffer('image/png'));}else for(let n=0;n<720;n++)fs.writeFileSync(`${out}/${String(n).padStart(4,'0')}.png`,draw(n/30).toBuffer('image/png'));
