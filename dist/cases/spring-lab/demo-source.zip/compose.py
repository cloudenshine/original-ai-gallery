import numpy as np,wave,json,os
sr=48000; dur=24; n=sr*dur; bg=np.zeros(n); fx=np.zeros(n)
# Four harmonic sections, deliberately quieter and less busy toward convergence.
chords=[[146.832,220,293.665,349.228],[130.813,196,261.626,329.628],[174.614,220,261.626,349.228],[146.832,220,293.665,440]]
def tone(arr,start,length,freq,amp,decay=0):
 k=int(start*sr);count=min(int(length*sr),len(arr)-k);t=np.arange(count)/sr
 env=np.minimum(1,t/.04)*np.minimum(1,(count/sr-t)/.16)
 if decay:env*=np.exp(-decay*t)
 arr[k:k+count]+=amp*env*(np.sin(2*np.pi*freq*t)+.18*np.sin(4*np.pi*freq*t))
for sec,ch in enumerate(chords):
 for f in ch:tone(bg,sec*6,6,f,.018)
 for j in range(8 if sec<2 else 4):tone(bg,sec*6+j*(.75 if sec<2 else 1.5),1.4,ch[j%4]*2,.026,2.3)
 for f in [660,880]:tone(fx,sec*6,.22,f,.045,16)
fade=np.minimum(1,np.arange(n)/sr/.4)*np.minimum(1,(n-np.arange(n))/sr/.8);bg*=fade
os.makedirs('audio',exist_ok=True)
for name,a in [('bgm',bg),('sfx',fx),('mix',bg+fx)]:
 with wave.open('audio/'+name+'.wav','wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(a,-1,1)*32767).astype('<i2').tobytes())
json.dump({'duration':24,'sampleRate':sr,'provenance':'Original program-synthesized music and UI reset cues; not a physical spring recording.','events':[{'time':i*6,'damping':[.15,.55,1,1.2][i],'event':'response reset / synthesized cue'} for i in range(4)],'peak':float(np.max(np.abs(bg+fx)))},open('events.json','w'),indent=2)
