import assert from 'node:assert/strict';import{springPosition as y}from'./model.mjs';
// Independent numerical ODE: x'' + 2ζω x' + ω²x = ω².
const results=[];
for(const z of [.15,.55,1,1.2]){let x=0,v=0,dt=.0001,maxError=0,peak=0,prev=0,monotonic=true;for(let i=0;i<60000;i++){let a=(x,v)=>25-10*z*v-25*x;let k1x=v,k1v=a(x,v),k2x=v+dt*k1v/2,k2v=a(x+dt*k1x/2,v+dt*k1v/2),k3x=v+dt*k2v/2,k3v=a(x+dt*k2x/2,v+dt*k2v/2),k4x=v+dt*k3v,k4v=a(x+dt*k3x,v+dt*k3v);x+=dt*(k1x+2*k2x+2*k3x+k4x)/6;v+=dt*(k1v+2*k2v+2*k3v+k4v)/6;let exact=y((i+1)*dt,z);maxError=Math.max(maxError,Math.abs(x-exact));peak=Math.max(peak,exact);if(exact<prev-1e-10)monotonic=false;prev=exact;}
assert.equal(y(0,z),0);assert(maxError<1e-9);if(z<1)assert(peak>1);else{assert(monotonic);assert(peak<=1)}results.push({z,maxError,peak,end:y(6,z),monotonic});}
console.log(JSON.stringify(results,null,2));
