#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 compose.py
node render.mjs frames
ffmpeg -v error -y -framerate 30 -i frames/%04d.png -i audio/mix.wav -c:v libx264 -preset medium -crf 23 -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart -t 24 demo.mp4
ffmpeg -v error -y -i audio/bgm.wav audio/bgm.flac
ffmpeg -v error -y -i audio/sfx.wav audio/sfx.flac
