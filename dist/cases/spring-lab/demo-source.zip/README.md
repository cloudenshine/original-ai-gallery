# 回到平衡 · 可播放演示源码

现有交互作品的 24 秒数学动画导出。四段依次使用阻尼比 ζ=0.15、0.55、1.00、1.20，每段按真实模型时间运行六秒。ωₙ=5 rad/s，归一化单位阶跃响应，非实测数据；不是性能承诺。

## 恢复与渲染

需要已有 Node 20+、@napi-rs/canvas、Python 3/NumPy、FFmpeg，以及 Noto Sans CJK 字体。设置 CJK_FONT 为本机字体文件路径（默认 /usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc）。不含自动安装程序。运行 bash render.sh，生成 demo.mp4。可先运行 node render.mjs preview --still 验证字体和画面。

model.mjs 与现有交互作品完全相同。render.mjs 用同一函数作图；compose.py 从头合成配乐与参数重置音效。audio/bgm.flac、audio/sfx.flac 是无损分轨，可以通过 FFmpeg 解码或重新生成；无需下载外部音乐。events.json 保留共用时间提示点。源包不含冗余混音 WAV、成片或中间帧。

这是固定参数的可播放演示，原页面滑杆、播放和恢复默认交互仍可使用。成片经过媒体元数据核验、全文件解码、编码画面抽检和独立模型检查；未完成真人连续观看听音和实际浏览器测试，未作听感或观众理解验收保证。

程序图形、配乐和音效为本次任务新制。音效是合成界面提示音，不是弹簧实录。公开复用许可待定。系统字体不打包，按字体自身许可安装使用。SOURCE-MANIFEST.json 列出源包其他每个成员的 SHA-256，可供完整性校验。
