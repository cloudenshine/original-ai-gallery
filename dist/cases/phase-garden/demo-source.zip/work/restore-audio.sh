#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
ffmpeg -v error -y -i output/bgm.flac -c:a pcm_s16le output/bgm.wav
ffmpeg -v error -y -i output/sfx.flac -c:a pcm_s16le output/sfx.wav
ffmpeg -v error -y -i output/bgm.wav -i output/sfx.wav -filter_complex '[0:a][1:a]amix=inputs=2:normalize=0' -c:a pcm_s16le output/mix.wav
# The original generator reproduces the exact reference mix from pre-quantization floats:
# python work/compose-audio.py
