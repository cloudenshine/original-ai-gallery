# Phase Garden playable demonstration source

This package preserves the original interactive artwork in original/index.html and exports its exact motion-core and drawing function at amplitude 0.80. It is a 30-second fixed default-state performance, not a recording of browser interaction. The original controls remain available on the case page.

Original score: a soft D/A/E harmonic bed, staggered plucked notes reflecting the phase offsets, and chimes at 0, 7.5, 15 and 22.5 seconds. The chimes are musical accents, not physical measurements. BGM and SFX are separate lossless FLAC stems preserving the exact 16-bit PCM samples. Run sh work/restore-audio.sh to decode WAV stems and reconstruct a mix, or run the Python generator to reproduce the exact reference mix from pre-quantization floats. The redundant mix WAV is not included. No external music or paid generation service was used. The music fades out; the video is not claimed to be a seamless audiovisual loop.

Rebuild from this folder's parent: Python 3 with numpy; Node.js with @napi-rs/canvas; FFmpeg; Noto CJK font at the path in render-demo.cjs. No package versions are fetched by these scripts.

python work/compose-audio.py
node work/render-demo.cjs

Outputs are written in output/. Rendering uses native Skia Canvas and preserves the original equations and stroke behavior. Native font rendering can differ from a browser. The MP4's wrapper is a noninteractive presentation, not a screenshot of the page.

Technical checks: 900 frames, 1280×800, 30 fps, H.264 yuv420p + stereo 48 kHz AAC, 30 seconds. Full-file decode and original core tests passed. Selected frames were visually inspected. Browser controls, continuous visual playback and subjective listening were not verified in this environment. This source package does not contain the MP4; download it separately from the case page.

SOURCE-MANIFEST.json hashes every other ZIP entry, excluding itself to avoid a circular hash.
