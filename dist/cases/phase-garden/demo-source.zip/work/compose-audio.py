import numpy as np,wave,os
root=os.path.dirname(os.path.dirname(__file__));sr=48000;n=sr*30;t=np.arange(n)/sr
bgm=np.zeros((n,2));sfx=np.zeros_like(bgm)
# Original score: four staggered harmonic entries mirror the orbit phase offsets.
for j,f in enumerate([146.832384,220.,293.664768,329.627557,440.]):
    env=(.65+.35*np.cos(2*np.pi*t/30+j*2*np.pi/5))*.035
    tone=np.sin(2*np.pi*f*t+.09*np.sin(2*np.pi*t/7.5+j))+.22*np.sin(4*np.pi*f*t)
    pan=.5+.35*np.sin(j*2*np.pi/5)
    bgm[:,0]+=tone*env*np.sqrt(1-pan);bgm[:,1]+=tone*env*np.sqrt(pan)
notes=[293.664768,440.,329.627557,587.329536,493.883301,440.,329.627557]
for q in range(4):
    for j,f in enumerate(notes):
        onset=q*7.5+j*.85+.4;u=t-onset;env=np.where(u>=0,(1-np.exp(-np.maximum(u,0)*100))*np.exp(-np.maximum(u,0)*2),0)
        tone=(np.sin(2*np.pi*f*u)+.25*np.sin(2*np.pi*f*2*u))*.09*env
        pan=.15+.7*j/6;bgm[:,0]+=tone*np.sqrt(1-pan);bgm[:,1]+=tone*np.sqrt(pan)
for onset in [0,7.5,15,22.5]:
    u=t-onset;v=np.maximum(u,0);env=np.where(u>=0,(1-np.exp(-v*160))*np.exp(-v*3.8),0)
    chime=.06*env*(np.sin(2*np.pi*880*u)+.4*np.sin(2*np.pi*1320*u))
    sfx[:,0]+=chime;sfx[:,1]+=chime
fade=np.minimum(1,t/.4)*np.minimum(1,(30-t)/1.2)
bgm*=fade[:,None];sfx*=fade[:,None]
scale=.8/np.max(np.abs(bgm+sfx));bgm*=scale;sfx*=scale
for name,x in [('bgm',bgm),('sfx',sfx),('mix',bgm+sfx)]:
    with wave.open(root+'/output/'+name+'.wav','wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
    print(name,'peak',np.max(np.abs(x)),'rms',np.sqrt(np.mean(x*x)))
